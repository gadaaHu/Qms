@echo off
title GadaH Queue Management System Setup
color 0A

echo ========================================
echo   G A D A H   Q U E U E   S Y S T E M
echo         Complete Installation
echo ========================================
echo.

echo [1/5] Checking Node.js Installation...
node --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Node.js is not installed or not in PATH
    echo Please install Node.js from https://nodejs.org/
    pause
    exit /b 1
)
echo ✅ Node.js version: 
node --version
echo.

echo [2/5] Installing Backend Dependencies...
cd backend
if errorlevel 1 (
    echo ❌ Backend folder not found!
    pause
    exit /b 1
)
echo Installing packages from package.json...
call npm install
if errorlevel 1 (
    echo ❌ Backend installation failed
    pause
    exit /b 1
)
echo ✅ Backend dependencies installed successfully
echo.

echo [3/5] Installing Frontend Dependencies...
cd ../frontend
if errorlevel 1 (
    echo ❌ Frontend folder not found!
    pause
    exit /b 1
)
echo Installing packages from package.json...
call npm install
if errorlevel 1 (
    echo ❌ Frontend installation failed
    pause
    exit /b 1
)
echo ✅ Frontend dependencies installed successfully
echo.

echo [4/5] Checking MongoDB Connection...
cd ../backend
echo Testing connection to GadaH Database...
node -e "const mongoose = require('mongoose'); mongoose.connect('mongodb://localhost:27017/GadaH', { serverSelectionTimeoutMS: 5000 }).then(() => { console.log('✅ Connected to GadaH Database'); process.exit(0); }).catch(err => { console.error('❌ Connection failed:', err.message); process.exit(1); });"
if errorlevel 1 (
    echo.
    echo ⚠️  MongoDB is not running or GadaH database not accessible
    echo.
    echo Please start MongoDB first:
    echo    - Windows: net start MongoDB
    echo    - Or: "C:\Program Files\MongoDB\Server\7.0\bin\mongod.exe" --dbpath="C:\data\db"
    echo.
    echo If MongoDB is not installed:
    echo    Download from: https://www.mongodb.com/try/download/community
    echo.
    pause
    exit /b 1
)
echo ✅ MongoDB is running and GadaH database is ready
echo.

echo [5/5] Initializing GadaH Database...
echo Creating system data, roles, privileges, and admin user...
call npm run init-system
if errorlevel 1 (
    echo ❌ Database initialization failed
    echo.
    echo Please check:
    echo   1. MongoDB is running
    echo   2. No other process is using port 27017
    echo   3. You have write permissions
    pause
    exit /b 1
)
echo ✅ GadaH Database initialized successfully
echo.

echo ========================================
echo   ✅ GADAH SYSTEM INSTALLATION COMPLETE!
echo ========================================
echo.
echo ╔══════════════════════════════════════════════════════════════╗
echo ║                    G A D A H   Q M S                         ║
echo ╠══════════════════════════════════════════════════════════════╣
echo ║ 🚀 System Name:     GadaH Queue Management System            ║
echo ║ 💾 Database:        GadaH                                     ║
echo ║ 📧 Admin Email:     admin@gadah.com                           ║
echo ║ 🔑 Admin Password:  admin123                                  ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.
echo To start the GadaH System:
echo.
echo ┌─────────────────────────────────────────────────────────────┐
echo │  Backend Server:                                            │
echo │    cd backend && npm run dev                                │
echo │    http://localhost:5000                                    │
echo │    http://localhost:5000/health (for health check)         │
echo └─────────────────────────────────────────────────────────────┘
echo.
echo ┌─────────────────────────────────────────────────────────────┐
echo │  Frontend Application:                                      │
echo │    cd frontend && npm run dev                               │
echo │    http://localhost:3000                                    │
echo └─────────────────────────────────────────────────────────────┘
echo.
echo ┌─────────────────────────────────────────────────────────────┐
echo │  Or using Docker:                                           │
echo │    docker-compose up -d                                     │
echo │    http://localhost:3000 (Frontend)                         │
echo │    http://localhost:5000 (Backend API)                      │
echo └─────────────────────────────────────────────────────────────┘
echo.
echo ┌─────────────────────────────────────────────────────────────┐
echo │  Login Credentials:                                         │
echo │    Email: admin@gadah.com                                   │
echo │    Password: admin123                                       │
echo └─────────────────────────────────────────────────────────────┘
echo.
echo ========================================
echo   Need help? Check the documentation:
echo   - Backend README: backend/README.md
echo   - Frontend README: frontend/README.md
echo ========================================
echo.
pause