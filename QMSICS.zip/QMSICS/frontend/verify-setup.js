const mongoose = require('mongoose');
const axios = require('axios');
const { execSync } = require('child_process');

async function verifySetup() {
    console.log('\n========================================');
    console.log('  QMS System Verification');
    console.log('========================================\n');

    // 1. Check Node.js version
    console.log('1. Node.js Version:');
    const nodeVersion = process.version;
    console.log(`   ✓ Node.js ${nodeVersion}`);

    if (parseInt(nodeVersion.slice(1)) < 18) {
        console.log('   ⚠️  Node.js version should be >= 18.0.0');
    }
    console.log();

    // 2. Check MongoDB connection
    console.log('2. MongoDB Connection:');
    try {
        await mongoose.connect('mongodb://localhost:27017', { serverSelectionTimeoutMS: 5000 });
        console.log('   ✅ MongoDB is running');
        await mongoose.disconnect();
    } catch (error) {
        console.log('   ❌ MongoDB is not running');
        console.log('   Please start MongoDB first');
    }
    console.log();

    // 3. Check Backend dependencies
    console.log('3. Backend Dependencies:');
    const backendPackage = require('./backend/package.json');
    const requiredBackendPackages = ['express', 'mongoose', 'cors', 'dotenv', 'bcryptjs', 'jsonwebtoken', 'socket.io'];

    requiredBackendPackages.forEach(pkg => {
        if (backendPackage.dependencies[pkg] || backendPackage.devDependencies[pkg]) {
            console.log(`   ✅ ${pkg}: ${backendPackage.dependencies[pkg] || backendPackage.devDependencies[pkg]}`);
        } else {
            console.log(`   ❌ ${pkg}: Not found`);
        }
    });
    console.log();

    // 4. Check Frontend dependencies
    console.log('4. Frontend Dependencies:');
    const frontendPackage = require('./frontend/package.json');
    const requiredFrontendPackages = ['react', 'react-dom', 'react-router-dom', 'axios', 'socket.io-client', 'vite'];

    requiredFrontendPackages.forEach(pkg => {
        if (frontendPackage.dependencies[pkg] || frontendPackage.devDependencies[pkg]) {
            console.log(`   ✅ ${pkg}: ${frontendPackage.dependencies[pkg] || frontendPackage.devDependencies[pkg]}`);
        } else {
            console.log(`   ❌ ${pkg}: Not found`);
        }
    });
    console.log();

    // 5. Check Tailwind configuration
    console.log('5. TailwindCSS Configuration:');
    try {
        const tailwindConfig = require('./frontend/tailwind.config.js');
        console.log('   ✅ tailwind.config.js exists');
    } catch (error) {
        console.log('   ❌ tailwind.config.js not found');
    }

    try {
        const postcssConfig = require('./frontend/postcss.config.js');
        console.log('   ✅ postcss.config.js exists');
    } catch (error) {
        console.log('   ❌ postcss.config.js not found');
    }
    console.log();

    // 6. Check Vite configuration
    console.log('6. Vite Configuration:');
    try {
        const viteConfig = require('./frontend/vite.config.js');
        console.log('   ✅ vite.config.js exists');
    } catch (error) {
        console.log('   ❌ vite.config.js not found');
    }
    console.log();

    // 7. Check environment files
    console.log('7. Environment Files:');
    const fs = require('fs');

    if (fs.existsSync('./backend/.env')) {
        console.log('   ✅ backend/.env exists');
    } else {
        console.log('   ⚠️  backend/.env not found (copy from .env.example)');
    }

    if (fs.existsSync('./frontend/.env')) {
        console.log('   ✅ frontend/.env exists');
    } else {
        console.log('   ⚠️  frontend/.env not found (copy from .env.example)');
    }
    console.log();

    console.log('========================================');
    console.log('  Verification Complete');
    console.log('========================================\n');

    console.log('To start the application:');
    console.log('  Backend:  cd backend && npm run dev');
    console.log('  Frontend: cd frontend && npm run dev');
    console.log('\nAccess the application:');
    console.log('  Frontend: http://localhost:3000');
    console.log('  Backend API: http://localhost:5000');
    console.log('  Health Check: http://localhost:5000/health');
    console.log();
}

verifySetup().catch(console.error);