import React, { lazy, Suspense, useEffect } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@hooks/useAuth';
import { useSocket } from '@hooks/useSocket';
import LoadingSpinner from '@components/Common/LoadingSpinner';
import PrivateRoute from '@components/Common/PrivateRoute';
import MainLayout from '@components/Layout/MainLayout';
import { Helmet } from 'react-helmet-async';
import { toast } from 'react-hot-toast';

// Lazy load pages for better performance
const Login = lazy(() => import('@pages/Login'));
const Dashboard = lazy(() => import('@pages/Dashboard'));
const Kiosk = lazy(() => import('@pages/Kiosk'));
const QueueStatus = lazy(() => import('@pages/QueueStatus'));
const NotFound = lazy(() => import('@pages/NotFound'));
const Profile = lazy(() => import('@pages/Profile'));
const Settings = lazy(() => import('@pages/Settings'));

// Admin Routes
const AdminDashboard = lazy(() => import('@pages/admin/AdminDashboard'));
const UserManagement = lazy(() => import('@pages/admin/UserManagement'));
const RoleManagement = lazy(() => import('@pages/admin/RoleManagement'));
const ZoneManagement = lazy(() => import('@pages/admin/ZoneManagement'));
const CounterManagement = lazy(() => import('@pages/admin/CounterManagement'));
const ServiceManagement = lazy(() => import('@pages/admin/ServiceManagement'));
const SystemConfig = lazy(() => import('@pages/admin/SystemConfig'));
const AuditLogs = lazy(() => import('@pages/admin/AuditLogs'));

// Supervisor Routes
const SupervisorDashboard = lazy(() => import('@pages/supervisor/SupervisorDashboard'));
const RealTimeMonitor = lazy(() => import('@pages/supervisor/RealTimeMonitor'));
const EscalationPanel = lazy(() => import('@pages/supervisor/EscalationPanel'));
const PriorityManager = lazy(() => import('@pages/supervisor/PriorityManager'));
const PerformanceReports = lazy(() => import('@pages/supervisor/PerformanceReports'));

// Operator Routes
const OperatorPanel = lazy(() => import('@pages/operator/OperatorPanel'));
const CounterDisplay = lazy(() => import('@pages/operator/CounterDisplay'));
const CallNextTicket = lazy(() => import('@pages/operator/CallNextTicket'));
const ServiceComplete = lazy(() => import('@pages/operator/ServiceComplete'));

// Customer Routes
const TicketGenerator = lazy(() => import('@pages/customer/TicketGenerator'));
const TicketDetails = lazy(() => import('@pages/customer/TicketDetails'));
const QueueDisplay = lazy(() => import('@pages/customer/QueueDisplay'));

// Define routes that should NOT use the MainLayout (public routes without sidebar/navbar)
const routesWithoutLayout = [
    '/login',
    '/kiosk',
    '/queue',
    '/queue-display',
    '/get-ticket',
    '/ticket'
];

// Helper function to check if a route should use layout
const shouldUseLayout = (pathname) => {
    return !routesWithoutLayout.some(route => pathname.startsWith(route));
};

// Helper to render with layout
const renderWithLayout = (element) => <MainLayout>{element}</MainLayout>;

function App() {
    const { user, loading, isAuthenticated, checkAuth } = useAuth();
    const { isConnected } = useSocket();
    const location = useLocation();

    // Check authentication on mount
    useEffect(() => {
        checkAuth();
    }, [checkAuth]);

    // Monitor connection status
    useEffect(() => {
        if (!isConnected && isAuthenticated) {
            toast.error('Connection lost. Reconnecting...', { id: 'connection-lost' });
        } else if (isConnected && isAuthenticated) {
            toast.success('Connected to server', { id: 'connection-restored', duration: 2000 });
        }
    }, [isConnected, isAuthenticated]);

    // Show loading spinner while checking auth
    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-600 to-secondary-600">
                <LoadingSpinner size="large" text="Loading GadaH System..." />
            </div>
        );
    }

    return (
        <>
            <Helmet>
                <title>GadaH Queue Management System</title>
                <meta name="description" content="GadaH Queue Management System - Efficient queue management solution" />
                <meta name="theme-color" content="#667eea" />
                <link rel="icon" type="image/x-icon" href="/favicon.ico" />
            </Helmet>

            <Suspense fallback={
                <div className="min-h-screen flex items-center justify-center">
                    <LoadingSpinner size="medium" text="Loading page..." />
                </div>
            }>
                <Routes>
                    {/* Public Routes - No Layout */}
                    <Route path="/login" element={<Login />} />
                    <Route path="/kiosk" element={<Kiosk />} />
                    <Route path="/queue" element={<QueueStatus />} />
                    <Route path="/queue-display" element={<QueueDisplay />} />
                    <Route path="/get-ticket" element={<TicketGenerator />} />
                    <Route path="/ticket/:id" element={<TicketDetails />} />

                    {/* Protected Routes - With Layout (Sidebar + Navbar) */}

                    {/* Dashboard */}
                    <Route
                        path="/dashboard"
                        element={
                            <PrivateRoute>
                                {renderWithLayout(<Dashboard />)}
                            </PrivateRoute>
                        }
                    />

                    {/* Profile & Settings */}
                    <Route
                        path="/profile"
                        element={
                            <PrivateRoute>
                                {renderWithLayout(<Profile />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/settings"
                        element={
                            <PrivateRoute>
                                {renderWithLayout(<Settings />)}
                            </PrivateRoute>
                        }
                    />

                    {/* Admin Routes */}
                    <Route
                        path="/admin"
                        element={
                            <PrivateRoute roles={['admin', 'super_admin']}>
                                {renderWithLayout(<AdminDashboard />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/admin/users"
                        element={
                            <PrivateRoute roles={['admin', 'super_admin']}>
                                {renderWithLayout(<UserManagement />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/admin/roles"
                        element={
                            <PrivateRoute roles={['admin', 'super_admin']}>
                                {renderWithLayout(<RoleManagement />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/admin/zones"
                        element={
                            <PrivateRoute roles={['admin', 'super_admin']}>
                                {renderWithLayout(<ZoneManagement />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/admin/counters"
                        element={
                            <PrivateRoute roles={['admin', 'super_admin']}>
                                {renderWithLayout(<CounterManagement />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/admin/services"
                        element={
                            <PrivateRoute roles={['admin', 'super_admin']}>
                                {renderWithLayout(<ServiceManagement />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/admin/config"
                        element={
                            <PrivateRoute roles={['admin', 'super_admin']}>
                                {renderWithLayout(<SystemConfig />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/admin/audit-logs"
                        element={
                            <PrivateRoute roles={['admin', 'super_admin']}>
                                {renderWithLayout(<AuditLogs />)}
                            </PrivateRoute>
                        }
                    />

                    {/* Supervisor Routes */}
                    <Route
                        path="/supervisor"
                        element={
                            <PrivateRoute roles={['supervisor', 'admin', 'super_admin']}>
                                {renderWithLayout(<SupervisorDashboard />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/supervisor/monitor"
                        element={
                            <PrivateRoute roles={['supervisor', 'admin', 'super_admin']}>
                                {renderWithLayout(<RealTimeMonitor />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/supervisor/escalate"
                        element={
                            <PrivateRoute roles={['supervisor', 'admin', 'super_admin']}>
                                {renderWithLayout(<EscalationPanel />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/supervisor/priority"
                        element={
                            <PrivateRoute roles={['supervisor', 'admin', 'super_admin']}>
                                {renderWithLayout(<PriorityManager />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/supervisor/reports"
                        element={
                            <PrivateRoute roles={['supervisor', 'admin', 'super_admin']}>
                                {renderWithLayout(<PerformanceReports />)}
                            </PrivateRoute>
                        }
                    />

                    {/* Operator Routes */}
                    <Route
                        path="/operator"
                        element={
                            <PrivateRoute roles={['operator', 'supervisor', 'admin', 'super_admin']}>
                                {renderWithLayout(<OperatorPanel />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/operator/counter/:counterId"
                        element={
                            <PrivateRoute roles={['operator', 'supervisor', 'admin', 'super_admin']}>
                                {renderWithLayout(<CounterDisplay />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/operator/call-next"
                        element={
                            <PrivateRoute roles={['operator', 'supervisor', 'admin', 'super_admin']}>
                                {renderWithLayout(<CallNextTicket />)}
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/operator/complete/:ticketId"
                        element={
                            <PrivateRoute roles={['operator', 'supervisor', 'admin', 'super_admin']}>
                                {renderWithLayout(<ServiceComplete />)}
                            </PrivateRoute>
                        }
                    />

                    {/* Default Routes */}
                    <Route
                        path="/"
                        element={
                            isAuthenticated ? <Navigate to="/dashboard" /> : <Navigate to="/login" />
                        }
                    />
                    <Route path="*" element={renderWithLayout(<NotFound />)} />
                </Routes>
            </Suspense>
        </>
    );
}

export default App;