import api from './api';

class TicketService {
    async createTicket(data) {
        const response = await api.post('/tickets', data);
        return response.data;
    }

    async getTickets(params = {}) {
        const response = await api.get('/tickets', { params });
        return response.data;
    }

    async getTicket(id) {
        const response = await api.get(`/tickets/${id}`);
        return response.data;
    }

    async getQueueStatus() {
        const response = await api.get('/tickets/queue');
        return response.data;
    }

    async updateTicketStatus(id, status, counterId, operatorId) {
        const response = await api.put(`/tickets/${id}/status`, { status, counterId, operatorId });
        return response.data;
    }

    async rateTicket(id, rating, feedback) {
        const response = await api.post(`/tickets/${id}/rate`, { rating, feedback });
        return response.data;
    }

    async getTicketStats() {
        const response = await api.get('/tickets/stats');
        return response.data;
    }
}

export default new TicketService();