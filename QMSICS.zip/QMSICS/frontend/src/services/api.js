import axios from 'axios';
import { toast } from 'react-hot-toast';

// Configuration
const API_CONFIG = {
    baseURL: import.meta.env.VITE_API_URL || '/api',
    timeout: 30000,
    retryAttempts: 3,
    retryDelay: 1000,
    enableLogs: import.meta.env.VITE_ENABLE_LOGS === 'true'
};

// Create axios instance
const api = axios.create({
    baseURL: API_CONFIG.baseURL,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    },
    timeout: API_CONFIG.timeout,
    withCredentials: true,
});

// Request queue for handling concurrent requests
let isRefreshing = false;
let failedQueue = [];

const processQueue = (error, token = null) => {
    failedQueue.forEach(prom => {
        if (error) {
            prom.reject(error);
        } else {
            prom.resolve(token);
        }
    });
    failedQueue = [];
};

// Generate unique request ID
const generateRequestId = () => {
    return `${Date.now()}-${Math.random().toString(36).substring(2, 10)}`;
};

// Log request details
const logRequest = (config, requestId) => {
    if (!API_CONFIG.enableLogs) return;

    console.group(`📤 API Request [${requestId}]`);
    console.log(`Method: ${config.method?.toUpperCase()}`);
    console.log(`URL: ${config.url}`);
    console.log(`Params:`, config.params);
    console.log(`Data:`, config.data);
    console.log(`Headers:`, {
        ...config.headers,
        Authorization: config.headers.Authorization ? 'Bearer [REDACTED]' : undefined
    });
    console.groupEnd();
};

// Log response details
const logResponse = (response, requestId, startTime) => {
    if (!API_CONFIG.enableLogs) return;

    const duration = Date.now() - startTime;
    console.group(`📥 API Response [${requestId}]`);
    console.log(`Status: ${response.status} ${response.statusText}`);
    console.log(`Duration: ${duration}ms`);
    console.log(`Data:`, response.data);
    console.groupEnd();
};

// Log error details
const logError = (error, requestId, startTime) => {
    if (!API_CONFIG.enableLogs) return;

    const duration = Date.now() - startTime;
    console.group(`❌ API Error [${requestId}]`);
    console.log(`Duration: ${duration}ms`);
    console.log(`Status: ${error.response?.status}`);
    console.log(`Message: ${error.message}`);
    console.log(`Response:`, error.response?.data);
    console.groupEnd();
};

// Request interceptor
api.interceptors.request.use(
    (config) => {
        // Add request ID
        const requestId = generateRequestId();
        config.metadata = { requestId, startTime: Date.now() };
        config.headers['X-Request-ID'] = requestId;

        // Add auth token
        const token = localStorage.getItem('token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }

        // Log request
        logRequest(config, requestId);

        return config;
    },
    (error) => {
        console.error('Request interceptor error:', error);
        return Promise.reject(error);
    }
);

// Response interceptor
api.interceptors.response.use(
    (response) => {
        const { metadata } = response.config;
        if (metadata) {
            logResponse(response, metadata.requestId, metadata.startTime);
        }
        return response;
    },
    async (error) => {
        const originalRequest = error.config;

        if (!originalRequest) {
            return Promise.reject(error);
        }

        const { metadata } = originalRequest;
        if (metadata) {
            logError(error, metadata.requestId, metadata.startTime);
        }

        // Handle 401 Unauthorized - Token expired
        if (error.response?.status === 401 && !originalRequest._retry) {
            if (isRefreshing) {
                // Queue request while token is being refreshed
                return new Promise((resolve, reject) => {
                    failedQueue.push({ resolve, reject });
                }).then(token => {
                    originalRequest.headers.Authorization = `Bearer ${token}`;
                    return api(originalRequest);
                }).catch(err => Promise.reject(err));
            }

            originalRequest._retry = true;
            isRefreshing = true;

            try {
                const refreshToken = localStorage.getItem('refreshToken');
                if (!refreshToken) {
                    throw new Error('No refresh token available');
                }

                // Attempt to refresh token
                const response = await axios.post(
                    `${API_CONFIG.baseURL}/auth/refresh-token`,
                    { refreshToken },
                    { timeout: 5000 }
                );

                const { token } = response.data;
                localStorage.setItem('token', token);
                api.defaults.headers.common['Authorization'] = `Bearer ${token}`;

                // Process queued requests
                processQueue(null, token);

                // Retry original request
                originalRequest.headers.Authorization = `Bearer ${token}`;
                return api(originalRequest);

            } catch (refreshError) {
                // Refresh failed - clear auth and redirect to login
                processQueue(refreshError, null);

                // Clear all auth data
                localStorage.removeItem('token');
                localStorage.removeItem('refreshToken');
                localStorage.removeItem('user');

                // Clear axios default header
                delete api.defaults.headers.common['Authorization'];

                // Show error message
                toast.error('Session expired. Please login again.');

                // Redirect to login
                window.location.href = '/login';

                return Promise.reject(refreshError);
            } finally {
                isRefreshing = false;
            }
        }

        // Handle 403 Forbidden
        if (error.response?.status === 403) {
            toast.error('You don\'t have permission to perform this action');
        }

        // Handle 404 Not Found
        if (error.response?.status === 404) {
            toast.error('Resource not found');
        }

        // Handle 500 Server Error
        if (error.response?.status >= 500) {
            toast.error('Server error. Please try again later.');
        }

        // Handle network errors
        if (error.message === 'Network Error') {
            toast.error('Network error. Please check your connection.');
        }

        // Handle timeout
        if (error.code === 'ECONNABORTED') {
            toast.error('Request timeout. Please try again.');
        }

        // Extract error message
        const message = error.response?.data?.message || error.message || 'An error occurred';

        return Promise.reject({
            message,
            status: error.response?.status,
            data: error.response?.data,
            originalError: error
        });
    }
);

// Helper methods for common operations
api.helpers = {
    // Upload file with progress
    upload: (url, file, onProgress) => {
        const formData = new FormData();
        formData.append('file', file);

        return api.post(url, formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
            onUploadProgress: (progressEvent) => {
                if (onProgress) {
                    const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
                    onProgress(percentCompleted);
                }
            }
        });
    },

    // Download file
    download: async (url, filename) => {
        try {
            const response = await api.get(url, {
                responseType: 'blob'
            });

            const blob = new Blob([response.data]);
            const downloadUrl = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = downloadUrl;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(downloadUrl);

            return true;
        } catch (error) {
            console.error('Download failed:', error);
            toast.error('Download failed');
            return false;
        }
    },

    // Cancel request
    cancel: (cancelTokenSource) => {
        if (cancelTokenSource) {
            cancelTokenSource.cancel('Request cancelled by user');
        }
    },

    // Create cancel token
    createCancelToken: () => {
        return axios.CancelToken.source();
    }
};

// Add retry mechanism
api.retry = async (requestFn, retries = API_CONFIG.retryAttempts, delay = API_CONFIG.retryDelay) => {
    try {
        return await requestFn();
    } catch (error) {
        if (retries === 0) throw error;

        // Don't retry on 4xx errors (except 429)
        if (error.status && error.status >= 400 && error.status < 500 && error.status !== 429) {
            throw error;
        }

        await new Promise(resolve => setTimeout(resolve, delay));
        return api.retry(requestFn, retries - 1, delay * 2);
    }
};

// Add cache mechanism (simple memory cache)
const cache = new Map();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

api.cache = {
    get: (key) => {
        const cached = cache.get(key);
        if (cached && cached.expiry > Date.now()) {
            return cached.data;
        }
        cache.delete(key);
        return null;
    },

    set: (key, data, duration = CACHE_DURATION) => {
        cache.set(key, {
            data,
            expiry: Date.now() + duration
        });
    },

    clear: () => cache.clear(),

    remove: (key) => cache.delete(key)
};

// Enhanced get with caching
api.getCached = async (url, params, cacheDuration) => {
    const cacheKey = `${url}_${JSON.stringify(params)}`;
    const cached = api.cache.get(cacheKey);

    if (cached) {
        if (API_CONFIG.enableLogs) {
            console.log(`📦 Using cached data for: ${url}`);
        }
        return Promise.resolve(cached);
    }

    const response = await api.get(url, { params });
    api.cache.set(cacheKey, response.data, cacheDuration);
    return response;
};

// Add request queuing for same endpoints
const pendingRequests = new Map();

api.dedupe = async (url, requestFn) => {
    if (pendingRequests.has(url)) {
        return pendingRequests.get(url);
    }

    const promise = requestFn().finally(() => {
        pendingRequests.delete(url);
    });

    pendingRequests.set(url, promise);
    return promise;
};

// Export configured api instance
export default api;