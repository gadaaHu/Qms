export const API_ENDPOINTS = {
    // Auth
    AUTH: {
        LOGIN: '/auth/login',
        REGISTER: '/auth/register',
        LOGOUT: '/auth/logout',
        REFRESH_TOKEN: '/auth/refresh-token',
        FORGOT_PASSWORD: '/auth/forgot-password',
        RESET_PASSWORD: '/auth/reset-password',
    },

    // Tickets
    TICKETS: {
        BASE: '/tickets',
        GET_ALL: '/tickets',
        GET_BY_ID: (id) => `/tickets/${id}`,
        CREATE: '/tickets',
        UPDATE: (id) => `/tickets/${id}`,
        DELETE: (id) => `/tickets/${id}`,
        UPDATE_STATUS: (id) => `/tickets/${id}/status`,
        CALL_TICKET: (id) => `/tickets/${id}/call`,
        COMPLETE_TICKET: (id) => `/tickets/${id}/complete`,
    },

    // Services
    SERVICES: {
        BASE: '/services',
        GET_ALL: '/services',
        GET_BY_ID: (id) => `/services/${id}`,
        CREATE: '/services',
        UPDATE: (id) => `/services/${id}`,
        DELETE: (id) => `/services/${id}`,
    },

    // Counters
    COUNTERS: {
        BASE: '/counters',
        GET_ALL: '/counters',
        GET_BY_ID: (id) => `/counters/${id}`,
        CREATE: '/counters',
        UPDATE: (id) => `/counters/${id}`,
        DELETE: (id) => `/counters/${id}`,
        UPDATE_STATUS: (id) => `/counters/${id}/status`,
    },

    // Reports
    REPORTS: {
        DAILY: '/reports/daily',
        WEEKLY: '/reports/weekly',
        MONTHLY: '/reports/monthly',
        CUSTOM: '/reports/custom',
        DOWNLOAD: '/reports/download',
    },

    // Users
    USERS: {
        BASE: '/users',
        GET_ALL: '/users',
        GET_BY_ID: (id) => `/users/${id}`,
        CREATE: '/users',
        UPDATE: (id) => `/users/${id}`,
        DELETE: (id) => `/users/${id}`,
        UPDATE_PROFILE: '/users/profile',
        CHANGE_PASSWORD: '/users/change-password',
    },

    // Dashboard
    DASHBOARD: {
        STATISTICS: '/dashboard/statistics',
        LIVE_DATA: '/dashboard/live-data',
    },

    // Uploads
    UPLOADS: {
        SINGLE: '/uploads/single',
        MULTIPLE: '/uploads/multiple',
        PROFILE_IMAGE: '/uploads/profile-image',
    },
};