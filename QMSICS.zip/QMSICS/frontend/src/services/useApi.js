import { useState, useCallback } from 'react';
import api from '@services/api';
import toast from 'react-hot-toast';

export const useApi = () => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [data, setData] = useState(null);

    const execute = useCallback(async (requestFn, showToast = true) => {
        setLoading(true);
        setError(null);

        try {
            const result = await requestFn();
            setData(result);
            return result;
        } catch (err) {
            setError(err);
            if (showToast) {
                toast.error(err.response?.data?.message || err.message);
            }
            throw err;
        } finally {
            setLoading(false);
        }
    }, []);

    const reset = useCallback(() => {
        setLoading(false);
        setError(null);
        setData(null);
    }, []);

    return {
        loading,
        error,
        data,
        execute,
        reset,
        api, // Expose api instance for direct use
    };
};

// Specific hooks for common operations
export const useGet = (url, options = {}) => {
    const { loading, error, data, execute, reset } = useApi();
    const { immediate = true, cached = false, ttl, params } = options;

    const fetch = useCallback(async () => {
        return execute(() => {
            if (cached) {
                return api.getCached(url, params, ttl);
            }
            return api.get(url, { params });
        });
    }, [url, cached, ttl, params, execute]);

    const refetch = useCallback(() => {
        if (cached) {
            api.clearCache(url);
        }
        return fetch();
    }, [fetch, cached, url]);

    if (immediate) {
        fetch();
    }

    return {
        loading,
        error,
        data,
        fetch,
        refetch,
        reset,
    };
};

export const usePost = (url) => {
    const { loading, error, data, execute, reset } = useApi();

    const post = useCallback(async (postData, config = {}) => {
        return execute(() => api.post(url, postData, config));
    }, [url, execute]);

    return {
        loading,
        error,
        data,
        post,
        reset,
    };
};

export const usePut = (url) => {
    const { loading, error, data, execute, reset } = useApi();

    const put = useCallback(async (putData, config = {}) => {
        return execute(() => api.put(url, putData, config));
    }, [url, execute]);

    return {
        loading,
        error,
        data,
        put,
        reset,
    };
};

export const useDelete = (url) => {
    const { loading, error, data, execute, reset } = useApi();

    const deleteItem = useCallback(async (config = {}) => {
        return execute(() => api.delete(url, config));
    }, [url, execute]);

    return {
        loading,
        error,
        data,
        delete: deleteItem,
        reset,
    };
};