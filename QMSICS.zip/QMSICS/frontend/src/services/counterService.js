import api from './api';

class CounterService {
    async getCounters(params = {}) {
        const response = await api.get('/counters', { params });
        return response.data;
    }

    async getCounter(id) {
        const response = await api.get(`/counters/${id}`);
        return response.data;
    }

    async createCounter(data) {
        const response = await api.post('/counters', data);
        return response.data;
    }

    async updateCounter(id, data) {
        const response = await api.put(`/counters/${id}`, data);
        return response.data;
    }

    async deleteCounter(id) {
        const response = await api.delete(`/counters/${id}`);
        return response.data;
    }

    async callNextTicket(counterId) {
        const response = await api.post(`/counters/${counterId}/call`);
        return response.data;
    }

    async completeService(counterId, ticketId) {
        const response = await api.post(`/counters/${counterId}/complete/${ticketId}`);
        return response.data;
    }

    async startBreak(counterId) {
        const response = await api.post(`/counters/${counterId}/break`);
        return response.data;
    }

    async endBreak(counterId) {
        const response = await api.post(`/counters/${counterId}/resume`);
        return response.data;
    }

    async getCounterStats() {
        const response = await api.get('/counters/stats');
        return response.data;
    }
}

export default new CounterService();