// src/pages/Tickets.jsx
import { useGet, usePost, useDelete } from '../hooks/useApi';
import { API_ENDPOINTS } from '../services/endpoints';
import toast from 'react-hot-toast';

const Tickets = () => {
    // Get all tickets
    const { data: tickets, loading, fetch: refetch } = useGet(
        API_ENDPOINTS.TICKETS.GET_ALL
    );

    // Create ticket
    const { post: createTicket, loading: creating } = usePost(
        API_ENDPOINTS.TICKETS.CREATE
    );

    // Delete ticket
    const { delete: deleteTicket, loading: deleting } = useDelete();

    const handleCreateTicket = async () => {
        try {
            await createTicket({
                number: `T-${Date.now()}`,
                service: 'General',
            });
            toast.success('Ticket created successfully');
            refetch(); // Refresh the list
        } catch (error) {
            // Error handled by hook
        }
    };

    const handleDeleteTicket = async (id) => {
        if (window.confirm('Are you sure?')) {
            try {
                await deleteTicket(API_ENDPOINTS.TICKETS.DELETE(id));
                toast.success('Ticket deleted');
                refetch();
            } catch (error) {
                // Error handled by hook
            }
        }
    };

    if (loading) return <div>Loading tickets...</div>;

    return (
        <div>
            <button onClick={handleCreateTicket} disabled={creating}>
                {creating ? 'Creating...' : 'Create Ticket'}
            </button>

            <ul>
                {tickets?.map((ticket) => (
                    <li key={ticket._id}>
                        {ticket.number} - {ticket.status}
                        <button
                            onClick={() => handleDeleteTicket(ticket._id)}
                            disabled={deleting}
                        >
                            Delete
                        </button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Tickets;