export class AppError extends Error {
    constructor(message, statusCode, code) {
        super(message);
        this.statusCode = statusCode;
        this.code = code;
        this.name = 'AppError';
    }
}

export const handleApiError = (error) => {
    if (error.response) {
        // Server responded with error
        return {
            message: error.response.data.message || 'Server error occurred',
            statusCode: error.response.status,
            data: error.response.data,
        };
    } else if (error.request) {
        // Request made but no response
        return {
            message: 'Network error - unable to reach server',
            statusCode: 0,
            data: null,
        };
    } else {
        // Something else
        return {
            message: error.message || 'An error occurred',
            statusCode: -1,
            data: null,
        };
    }
};

export const isNetworkError = (error) => {
    return !error.response && error.request;
};

export const isAuthError = (error) => {
    return error.response?.status === 401;
};

export const isForbiddenError = (error) => {
    return error.response?.status === 403;
};

export const isNotFoundError = (error) => {
    return error.response?.status === 404;
};

export const isServerError = (error) => {
    return error.response?.status >= 500;
};