import React, { createContext, useContext, useEffect, useState } from 'react';
import io from 'socket.io-client';

const SocketContext = createContext();

export const useSocket = () => {
    const context = useContext(SocketContext);
    if (!context) {
        throw new Error('useSocket must be used within SocketProvider');
    }
    return context;
};

export const SocketProvider = ({ children }) => {
    const [socket, setSocket] = useState(null);
    const [isConnected, setIsConnected] = useState(false);

    useEffect(() => {
        // Get the token from localStorage
        const token = localStorage.getItem('token');

        // Connect to the backend WebSocket server
        const socketInstance = io('/', {
            transports: ['websocket', 'polling'],
            autoConnect: true,
            reconnection: true,
            reconnectionAttempts: 5,
            reconnectionDelay: 1000,
            auth: token ? { token } : undefined
        });

        socketInstance.on('connect', () => {
            console.log('🔌 Socket connected:', socketInstance.id);
            setIsConnected(true);

            // Authenticate with token if available
            if (token) {
                socketInstance.emit('authenticate', token);
            }
        });

        socketInstance.on('disconnect', () => {
            console.log('🔌 Socket disconnected');
            setIsConnected(false);
        });

        socketInstance.on('connect_error', (error) => {
            console.error('Socket connection error:', error);
            setIsConnected(false);
        });

        setSocket(socketInstance);

        // Cleanup on unmount
        return () => {
            socketInstance.disconnect();
        };
    }, []);

    // Join a specific room
    const joinRoom = (roomType, roomId) => {
        if (socket && isConnected) {
            socket.emit(`join-${roomType}`, roomId);
            console.log(`Joined ${roomType}: ${roomId}`);
        }
    };

    // Listen for events
    const on = (event, callback) => {
        if (socket) {
            socket.on(event, callback);
            return () => socket.off(event, callback);
        }
        return () => { };
    };

    // Emit events
    const emit = (event, data) => {
        if (socket && isConnected) {
            socket.emit(event, data);
        }
    };

    const value = {
        socket,
        isConnected,
        joinRoom,
        on,
        emit
    };

    return (
        <SocketContext.Provider value={value}>
            {children}
        </SocketContext.Provider>
    );
};