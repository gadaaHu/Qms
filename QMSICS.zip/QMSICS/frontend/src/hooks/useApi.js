import { useState, useCallback } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';

// Generic API hook
export const useApi = () => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [data, setData] = useState(null);

    const execute = useCallback(async (requestFn, showToast = true) => {
        setLoading(true);
        setError(null);

        try {
            const result = await requestFn();
            setData(result);
            return result;
        } catch (err) {
            setError(err);
            if (showToast) {
                toast.error(err.response?.data?.message || err.message);
            }
            throw err;
        } finally {
            setLoading(false);
        }
    }, []);

    return { loading, error, data, execute };
};

// GET hook
export const useGet = (url, options = {}) => {
    const { loading, error, data, execute } = useApi();
    const { immediate = true, params } = options;

    const fetch = useCallback(() => {
        return execute(() => api.get(url, { params }));
    }, [url, params, execute]);

    if (immediate) {
        fetch();
    }

    return { loading, error, data, fetch };
};

// POST hook
export const usePost = (url) => {
    const { loading, error, data, execute } = useApi();

    const post = useCallback((postData) => {
        return execute(() => api.post(url, postData));
    }, [url, execute]);

    return { loading, error, data, post };
};

// PUT hook
export const usePut = (url) => {
    const { loading, error, data, execute } = useApi();

    const put = useCallback((putData) => {
        return execute(() => api.put(url, putData));
    }, [url, execute]);

    return { loading, error, data, put };
};

// DELETE hook
export const useDelete = (url) => {
    const { loading, error, data, execute } = useApi();

    const deleteItem = useCallback(() => {
        return execute(() => api.delete(url));
    }, [url, execute]);

    return { loading, error, data, delete: deleteItem };
};