server.listen(PORT, () => {
    console.log(`
╔══════════════════════════════════════════════════════════════════════╗
║                  G A D A H   Q U E U E   S Y S T E M                 ║
╠══════════════════════════════════════════════════════════════════════╣
║ 🚀 Server:          http://localhost:${PORT}                              ║
║ 🔌 WebSocket:       ws://localhost:${PORT}                                 ║
║ 💾 Database:        GadaH - ${database.getConnectionStatus().padEnd(32)}║
║ 📡 Environment:     ${(process.env.NODE_ENV || 'development').padEnd(46)}║
║ 🌐 Frontend URL:    ${(process.env.CLIENT_URL || 'http://localhost:3000').padEnd(46)}║
╚══════════════════════════════════════════════════════════════════════╝
  `);
});