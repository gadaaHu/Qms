import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Sidebar from '@components/Common/Sidebar';
import Navbar from '@components/Common/Navbar';

const MainLayout = ({ children }) => {
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
    const location = useLocation();

    // Close sidebar on mobile when route changes
    useEffect(() => {
        setSidebarOpen(false);
    }, [location.pathname]);

    // Load sidebar preference from localStorage
    useEffect(() => {
        const savedPreference = localStorage.getItem('sidebarCollapsed');
        if (savedPreference !== null) {
            setSidebarCollapsed(savedPreference === 'true');
        }
    }, []);

    const handleSidebarToggle = () => {
        setSidebarOpen(!sidebarOpen);
    };

    const handleSidebarCollapse = (collapsed) => {
        setSidebarCollapsed(collapsed);
        localStorage.setItem('sidebarCollapsed', collapsed);
    };

    return (
        <div className="h-screen flex overflow-hidden bg-gray-100">
            {/* Sidebar */}
            <Sidebar
                isOpen={sidebarOpen}
                onToggle={handleSidebarToggle}
                collapsed={sidebarCollapsed}
                onCollapse={handleSidebarCollapse}
            />

            {/* Main Content Area */}
            <div className="flex-1 flex flex-col overflow-hidden transition-all duration-300">
                {/* Navbar */}
                <Navbar onMenuClick={handleSidebarToggle} />

                {/* Page Content */}
                <main className="flex-1 overflow-y-auto">
                    <div className="py-6 px-4 sm:px-6 lg:px-8">
                        {children}
                    </div>
                </main>
            </div>
        </div>
    );
};

export default MainLayout;