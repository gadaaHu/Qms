import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { toast } from 'react-hot-toast';
import { FiEdit2, FiTrash2, FiPlus, FiCheck, FiX } from 'react-icons/fi';

export default function RoleManagement() {
    const [roles, setRoles] = useState([]);
    const [privileges, setPrivileges] = useState([]);
    const [showForm, setShowForm] = useState(false);
    const [editingRole, setEditingRole] = useState(null);
    const [loading, setLoading] = useState(true);
    const [formData, setFormData] = useState({
        name: '',
        code: '',
        description: '',
        level: 0,
        privileges: []
    });

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const [rolesRes, privilegesRes] = await Promise.all([
                api.get('/admin/roles'),
                api.get('/admin/privileges')
            ]);
            setRoles(rolesRes.data.data);
            setPrivileges(privilegesRes.data.data);
        } catch (error) {
            toast.error('Failed to load data');
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (editingRole) {
                await api.put(`/admin/roles/${editingRole._id}`, formData);
                toast.success('Role updated successfully');
            } else {
                await api.post('/admin/roles', formData);
                toast.success('Role created successfully');
            }
            fetchData();
            resetForm();
        } catch (error) {
            toast.error(error.response?.data?.message || 'Operation failed');
        }
    };

    const handleDelete = async (id) => {
        if (!window.confirm('Are you sure you want to delete this role?')) return;

        try {
            await api.delete(`/admin/roles/${id}`);
            toast.success('Role deleted successfully');
            fetchData();
        } catch (error) {
            toast.error(error.response?.data?.message || 'Delete failed');
        }
    };

    const resetForm = () => {
        setFormData({
            name: '',
            code: '',
            description: '',
            level: 0,
            privileges: []
        });
        setEditingRole(null);
        setShowForm(false);
    };

    const editRole = (role) => {
        setEditingRole(role);
        setFormData({
            name: role.name,
            code: role.code,
            description: role.description || '',
            level: role.level,
            privileges: role.privileges.map(p => p._id)
        });
        setShowForm(true);
    };

    const togglePrivilege = (privilegeId) => {
        setFormData(prev => ({
            ...prev,
            privileges: prev.privileges.includes(privilegeId)
                ? prev.privileges.filter(id => id !== privilegeId)
                : [...prev.privileges, privilegeId]
        }));
    };

    const getPrivilegesByCategory = () => {
        const grouped = {};
        privileges.forEach(priv => {
            if (!grouped[priv.category]) grouped[priv.category] = [];
            grouped[priv.category].push(priv);
        });
        return grouped;
    };

    if (loading) {
        return <div className="flex justify-center p-8">Loading...</div>;
    }

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Role Management</h1>
                <button
                    onClick={() => setShowForm(true)}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
                >
                    <FiPlus /> Add Role
                </button>
            </div>

            {/* Role Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {roles.map(role => (
                    <div key={role._id} className="bg-white rounded-lg shadow-md p-6">
                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <h3 className="text-lg font-semibold">{role.name}</h3>
                                <p className="text-sm text-gray-500">{role.code}</p>
                            </div>
                            {!role.isSystem && (
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => editRole(role)}
                                        className="text-blue-600 hover:text-blue-800"
                                    >
                                        <FiEdit2 />
                                    </button>
                                    <button
                                        onClick={() => handleDelete(role._id)}
                                        className="text-red-600 hover:text-red-800"
                                    >
                                        <FiTrash2 />
                                    </button>
                                </div>
                            )}
                        </div>
                        <p className="text-sm text-gray-600 mb-4">{role.description}</p>
                        <div className="flex justify-between items-center text-sm">
                            <span className="text-gray-500">Level: {role.level}</span>
                            <span className="text-gray-500">
                                {role.privileges?.length || 0} privileges
                            </span>
                        </div>
                        {role.isSystem && (
                            <div className="mt-2 text-xs text-blue-600">System Role</div>
                        )}
                    </div>
                ))}
            </div>

            {/* Role Form Modal */}
            {showForm && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                        <div className="p-6 border-b">
                            <h2 className="text-xl font-bold">
                                {editingRole ? 'Edit Role' : 'Create New Role'}
                            </h2>
                        </div>
                        <form onSubmit={handleSubmit} className="p-6">
                            <div className="grid grid-cols-2 gap-4 mb-6">
                                <div>
                                    <label className="block text-sm font-medium mb-1">Role Name *</label>
                                    <input
                                        type="text"
                                        value={formData.name}
                                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                        className="w-full px-3 py-2 border rounded-lg"
                                        required
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Role Code *</label>
                                    <input
                                        type="text"
                                        value={formData.code}
                                        onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                                        className="w-full px-3 py-2 border rounded-lg"
                                        required
                                        disabled={editingRole?.isSystem}
                                    />
                                </div>
                                <div className="col-span-2">
                                    <label className="block text-sm font-medium mb-1">Description</label>
                                    <textarea
                                        value={formData.description}
                                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                        className="w-full px-3 py-2 border rounded-lg"
                                        rows="2"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Permission Level (0-100)</label>
                                    <input
                                        type="number"
                                        value={formData.level}
                                        onChange={(e) => setFormData({ ...formData, level: parseInt(e.target.value) })}
                                        className="w-full px-3 py-2 border rounded-lg"
                                        min="0"
                                        max="100"
                                    />
                                </div>
                            </div>

                            <div className="mb-6">
                                <label className="block text-sm font-medium mb-3">Privileges</label>
                                {Object.entries(getPrivilegesByCategory()).map(([category, privs]) => (
                                    <div key={category} className="mb-4">
                                        <h3 className="font-semibold text-gray-700 mb-2 capitalize">{category}</h3>
                                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                                            {privs.map(priv => (
                                                <label key={priv._id} className="flex items-center gap-2 text-sm">
                                                    <input
                                                        type="checkbox"
                                                        checked={formData.privileges.includes(priv._id)}
                                                        onChange={() => togglePrivilege(priv._id)}
                                                        className="rounded"
                                                    />
                                                    {priv.name}
                                                </label>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="flex justify-end gap-3 pt-4 border-t">
                                <button
                                    type="button"
                                    onClick={resetForm}
                                    className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                                >
                                    {editingRole ? 'Update' : 'Create'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}