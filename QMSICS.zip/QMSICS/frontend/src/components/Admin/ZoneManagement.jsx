import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { toast } from 'react-hot-toast';
import { FiEdit2, FiTrash2, FiPlus, FiMapPin, FiSettings } from 'react-icons/fi';

export default function ZoneManagement() {
    const [zones, setZones] = useState([]);
    const [counters, setCounters] = useState([]);
    const [showForm, setShowForm] = useState(false);
    const [editingZone, setEditingZone] = useState(null);
    const [loading, setLoading] = useState(true);
    const [formData, setFormData] = useState({
        name: '',
        code: '',
        description: '',
        location: { floor: '', building: '' },
        settings: {
            allowPriority: true,
            maxQueueLength: 50,
            displaySettings: { screenLayout: 'default', theme: 'light' }
        }
    });

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const [zonesRes, countersRes] = await Promise.all([
                api.get('/zones'),
                api.get('/counters')
            ]);
            setZones(zonesRes.data.data);
            setCounters(countersRes.data.data);
        } catch (error) {
            toast.error('Failed to load data');
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (editingZone) {
                await api.put(`/zones/${editingZone._id}`, formData);
                toast.success('Zone updated successfully');
            } else {
                await api.post('/zones', formData);
                toast.success('Zone created successfully');
            }
            fetchData();
            resetForm();
        } catch (error) {
            toast.error(error.response?.data?.message || 'Operation failed');
        }
    };

    const handleDelete = async (id) => {
        if (!window.confirm('Are you sure you want to delete this zone?')) return;

        try {
            await api.delete(`/zones/${id}`);
            toast.success('Zone deleted successfully');
            fetchData();
        } catch (error) {
            toast.error(error.response?.data?.message || 'Delete failed');
        }
    };

    const handleToggleStatus = async (id, currentStatus) => {
        try {
            await api.patch(`/zones/${id}/toggle-status`);
            toast.success(`Zone ${currentStatus ? 'deactivated' : 'activated'} successfully`);
            fetchData();
        } catch (error) {
            toast.error('Operation failed');
        }
    };

    const resetForm = () => {
        setFormData({
            name: '',
            code: '',
            description: '',
            location: { floor: '', building: '' },
            settings: {
                allowPriority: true,
                maxQueueLength: 50,
                displaySettings: { screenLayout: 'default', theme: 'light' }
            }
        });
        setEditingZone(null);
        setShowForm(false);
    };

    const editZone = (zone) => {
        setEditingZone(zone);
        setFormData({
            name: zone.name,
            code: zone.code,
            description: zone.description || '',
            location: zone.location || { floor: '', building: '' },
            settings: zone.settings || {
                allowPriority: true,
                maxQueueLength: 50,
                displaySettings: { screenLayout: 'default', theme: 'light' }
            }
        });
        setShowForm(true);
    };

    if (loading) {
        return <div className="flex justify-center p-8">Loading...</div>;
    }

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Zone Management</h1>
                <button
                    onClick={() => setShowForm(true)}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
                >
                    <FiPlus /> Add Zone
                </button>
            </div>

            {/* Zones Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {zones.map(zone => (
                    <div key={zone._id} className="bg-white rounded-lg shadow-md overflow-hidden">
                        <div className="p-6">
                            <div className="flex justify-between items-start mb-4">
                                <div>
                                    <h3 className="text-lg font-semibold">{zone.name}</h3>
                                    <p className="text-sm text-gray-500">{zone.code}</p>
                                </div>
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => editZone(zone)}
                                        className="text-blue-600 hover:text-blue-800"
                                    >
                                        <FiEdit2 />
                                    </button>
                                    <button
                                        onClick={() => handleDelete(zone._id)}
                                        className="text-red-600 hover:text-red-800"
                                    >
                                        <FiTrash2 />
                                    </button>
                                </div>
                            </div>

                            <p className="text-sm text-gray-600 mb-4">{zone.description}</p>

                            <div className="space-y-2 text-sm">
                                <div className="flex items-center gap-2 text-gray-500">
                                    <FiMapPin className="text-gray-400" />
                                    {zone.location?.building || 'No location set'}
                                </div>
                                <div className="flex items-center gap-2">
                                    <FiSettings className="text-gray-400" />
                                    <span>
                                        Priority: {zone.settings?.allowPriority ? 'Allowed' : 'Not allowed'} |
                                        Max Queue: {zone.settings?.maxQueueLength || 50}
                                    </span>
                                </div>
                            </div>

                            <div className="mt-4 pt-4 border-t flex justify-between items-center">
                                <div className="text-sm text-gray-500">
                                    {zone.assignedCounters?.length || 0} Counters
                                </div>
                                <button
                                    onClick={() => handleToggleStatus(zone._id, zone.isActive)}
                                    className={`px-3 py-1 rounded-full text-xs font-medium ${zone.isActive
                                            ? 'bg-green-100 text-green-800'
                                            : 'bg-gray-100 text-gray-800'
                                        }`}
                                >
                                    {zone.isActive ? 'Active' : 'Inactive'}
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Zone Form Modal */}
            {showForm && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div className="p-6 border-b">
                            <h2 className="text-xl font-bold">
                                {editingZone ? 'Edit Zone' : 'Create New Zone'}
                            </h2>
                        </div>
                        <form onSubmit={handleSubmit} className="p-6">
                            <div className="grid grid-cols-2 gap-4 mb-4">
                                <div>
                                    <label className="block text-sm font-medium mb-1">Zone Name *</label>
                                    <input
                                        type="text"
                                        value={formData.name}
                                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                        className="w-full px-3 py-2 border rounded-lg"
                                        required
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Zone Code *</label>
                                    <input
                                        type="text"
                                        value={formData.code}
                                        onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                                        className="w-full px-3 py-2 border rounded-lg"
                                        required
                                    />
                                </div>
                                <div className="col-span-2">
                                    <label className="block text-sm font-medium mb-1">Description</label>
                                    <textarea
                                        value={formData.description}
                                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                        className="w-full px-3 py-2 border rounded-lg"
                                        rows="2"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Building</label>
                                    <input
                                        type="text"
                                        value={formData.location.building}
                                        onChange={(e) => setFormData({
                                            ...formData,
                                            location: { ...formData.location, building: e.target.value }
                                        })}
                                        className="w-full px-3 py-2 border rounded-lg"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Floor</label>
                                    <input
                                        type="text"
                                        value={formData.location.floor}
                                        onChange={(e) => setFormData({
                                            ...formData,
                                            location: { ...formData.location, floor: e.target.value }
                                        })}
                                        className="w-full px-3 py-2 border rounded-lg"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Max Queue Length</label>
                                    <input
                                        type="number"
                                        value={formData.settings.maxQueueLength}
                                        onChange={(e) => setFormData({
                                            ...formData,
                                            settings: { ...formData.settings, maxQueueLength: parseInt(e.target.value) }
                                        })}
                                        className="w-full px-3 py-2 border rounded-lg"
                                        min="10"
                                        max="200"
                                    />
                                </div>
                                <div className="flex items-center">
                                    <label className="flex items-center gap-2">
                                        <input
                                            type="checkbox"
                                            checked={formData.settings.allowPriority}
                                            onChange={(e) => setFormData({
                                                ...formData,
                                                settings: { ...formData.settings, allowPriority: e.target.checked }
                                            })}
                                            className="rounded"
                                        />
                                        <span className="text-sm">Allow Priority Services</span>
                                    </label>
                                </div>
                            </div>

                            <div className="flex justify-end gap-3 pt-4 border-t">
                                <button
                                    type="button"
                                    onClick={resetForm}
                                    className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                                >
                                    {editingZone ? 'Update' : 'Create'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}