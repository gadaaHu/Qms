import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { toast } from 'react-hot-toast';
import { FiSave, FiRefreshCw } from 'react-icons/fi';

export default function SystemConfig() {
    const [configs, setConfigs] = useState([]);
    const [configMap, setConfigMap] = useState({});
    const [loading, setLoading] = useState(true);
    const [editing, setEditing] = useState(null);
    const [editValue, setEditValue] = useState('');

    useEffect(() => {
        fetchConfigs();
    }, []);

    const fetchConfigs = async () => {
        try {
            const res = await api.get('/admin/config');
            setConfigs(res.data.data);
            setConfigMap(res.data.configMap);
        } catch (error) {
            toast.error('Failed to load configurations');
        } finally {
            setLoading(false);
        }
    };

    const handleUpdate = async (key, value) => {
        try {
            await api.put(`/admin/config/${key}`, { value });
            toast.success('Configuration updated');
            fetchConfigs();
            setEditing(null);
        } catch (error) {
            toast.error('Update failed');
        }
    };

    const handleBulkUpdate = async () => {
        const updates = Object.entries(editValues).map(([key, value]) => ({ key, value }));
        try {
            await api.post('/admin/config/bulk', { updates });
            toast.success('All configurations saved');
            fetchConfigs();
        } catch (error) {
            toast.error('Save failed');
        }
    };

    const groupConfigs = () => {
        const groups = {};
        configs.forEach(config => {
            const category = config.category || 'general';
            if (!groups[category]) groups[category] = [];
            groups[category].push(config);
        });
        return groups;
    };

    const renderConfigInput = (config) => {
        const value = config.value;

        if (config.type === 'boolean') {
            return (
                <select
                    value={value ? 'true' : 'false'}
                    onChange={(e) => handleUpdate(config.key, e.target.value === 'true')}
                    className="px-3 py-1 border rounded-lg"
                >
                    <option value="true">Enabled</option>
                    <option value="false">Disabled</option>
                </select>
            );
        }

        if (config.type === 'array') {
            return (
                <textarea
                    value={Array.isArray(value) ? value.join(', ') : value}
                    onChange={(e) => handleUpdate(config.key, e.target.value.split(',').map(s => s.trim()))}
                    className="px-3 py-1 border rounded-lg w-full"
                    rows="2"
                />
            );
        }

        if (config.type === 'number') {
            return (
                <input
                    type="number"
                    value={value}
                    onChange={(e) => handleUpdate(config.key, parseFloat(e.target.value))}
                    className="px-3 py-1 border rounded-lg w-32"
                    min={config.validation?.min}
                    max={config.validation?.max}
                />
            );
        }

        return (
            <input
                type="text"
                value={value}
                onChange={(e) => handleUpdate(config.key, e.target.value)}
                className="px-3 py-1 border rounded-lg flex-1"
            />
        );
    };

    if (loading) {
        return <div className="flex justify-center p-8">Loading configurations...</div>;
    }

    const groups = groupConfigs();

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">System Configuration</h1>
                <button
                    onClick={fetchConfigs}
                    className="px-4 py-2 border rounded-lg flex items-center gap-2 hover:bg-gray-50"
                >
                    <FiRefreshCw /> Refresh
                </button>
            </div>

            {Object.entries(groups).map(([category, items]) => (
                <div key={category} className="mb-8">
                    <h2 className="text-xl font-semibold mb-4 capitalize">{category} Settings</h2>
                    <div className="bg-white rounded-lg shadow overflow-hidden">
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Setting</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Value</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200">
                                {items.map(config => (
                                    <tr key={config.key}>
                                        <td className="px-6 py-4">
                                            <div className="font-medium text-gray-900">{config.key}</div>
                                        </td>
                                        <td className="px-6 py-4">
                                            {renderConfigInput(config)}
                                        </td>
                                        <td className="px-6 py-4 text-sm text-gray-500">
                                            {config.description}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            ))}
        </div>
    );
}