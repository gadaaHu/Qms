// src/components/FileUpload.jsx
import { useState } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';

const FileUpload = () => {
    const [progress, setProgress] = useState(0);
    const [uploading, setUploading] = useState(false);

    const handleFileUpload = async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        setUploading(true);
        setProgress(0);

        try {
            const result = await api.helpers.upload(
                '/uploads/single',
                file,
                (percent) => setProgress(percent)
            );

            toast.success('File uploaded successfully!');
            console.log('Upload result:', result);
        } catch (error) {
            toast.error('Upload failed');
            console.error('Upload error:', error);
        } finally {
            setUploading(false);
            setTimeout(() => setProgress(0), 3000);
        }
    };

    return (
        <div>
            <input
                type="file"
                onChange={handleFileUpload}
                disabled={uploading}
            />
            {uploading && (
                <div>
                    <progress value={progress} max="100" />
                    <span>{progress}%</span>
                </div>
            )}
        </div>
    );
};

export default FileUpload;