import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@hooks/useAuth';
import { useSocket } from '@hooks/useSocket';
import {
    FiBell, FiUser, FiSettings, FiLogOut, FiMenu,
    FiSearch, FiChevronDown, FiHelpCircle, FiCheckCircle,
    FiAlertCircle
} from 'react-icons/fi';
import { format } from 'date-fns';

const Navbar = ({ onMenuClick }) => {
    const { user, logout } = useAuth();
    const { isConnected } = useSocket();
    const navigate = useNavigate();
    const [showUserMenu, setShowUserMenu] = useState(false);
    const [showNotifications, setShowNotifications] = useState(false);
    const [notifications, setNotifications] = useState([]);
    const [unreadCount, setUnreadCount] = useState(0);
    const userMenuRef = useRef(null);
    const notificationsRef = useRef(null);

    // Mock notifications - replace with real data from API
    useEffect(() => {
        // Simulate real-time notifications via socket
        const mockNotifications = [
            {
                id: 1,
                type: 'ticket',
                title: 'New Ticket',
                message: 'Ticket G001 has been created',
                time: new Date(),
                read: false
            },
            {
                id: 2,
                type: 'call',
                title: 'Ticket Called',
                message: 'Ticket G002 called to Counter 1',
                time: new Date(Date.now() - 5 * 60000),
                read: false
            },
            {
                id: 3,
                type: 'complete',
                title: 'Service Completed',
                message: 'Ticket G003 service completed',
                time: new Date(Date.now() - 10 * 60000),
                read: true
            }
        ];
        setNotifications(mockNotifications);
        setUnreadCount(mockNotifications.filter(n => !n.read).length);
    }, []);

    // Close dropdowns when clicking outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
                setShowUserMenu(false);
            }
            if (notificationsRef.current && !notificationsRef.current.contains(event.target)) {
                setShowNotifications(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleLogout = async () => {
        await logout();
        navigate('/login');
    };

    const getNotificationIcon = (type) => {
        switch (type) {
            case 'ticket':
                return <FiAlertCircle className="text-blue-500" />;
            case 'call':
                return <FiBell className="text-orange-500" />;
            case 'complete':
                return <FiCheckCircle className="text-green-500" />;
            default:
                return <FiBell className="text-gray-500" />;
        }
    };

    const markAsRead = (id) => {
        setNotifications(prev =>
            prev.map(n => n.id === id ? { ...n, read: true } : n)
        );
        setUnreadCount(prev => prev - 1);
    };

    const markAllAsRead = () => {
        setNotifications(prev => prev.map(n => ({ ...n, read: true })));
        setUnreadCount(0);
    };

    return (
        <nav className="bg-white shadow-sm sticky top-0 z-20">
            <div className="px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between h-16">
                    {/* Left section */}
                    <div className="flex items-center">
                        <button
                            onClick={onMenuClick}
                            className="lg:hidden p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none"
                        >
                            <FiMenu size={24} />
                        </button>
                        <div className="hidden lg:flex lg:items-center">
                            <div className="flex-shrink-0">
                                <h1 className="text-xl font-bold text-gray-900">GadaH QMS</h1>
                            </div>
                        </div>
                    </div>

                    {/* Center section - Search */}
                    <div className="flex-1 flex items-center justify-center px-2 lg:ml-6 lg:justify-end">
                        <div className="max-w-lg w-full lg:max-w-xs">
                            <div className="relative">
                                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <FiSearch className="h-5 w-5 text-gray-400" />
                                </div>
                                <input
                                    type="search"
                                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                                    placeholder="Search tickets, counters..."
                                />
                            </div>
                        </div>
                    </div>

                    {/* Right section */}
                    <div className="flex items-center space-x-4">
                        {/* Connection Status */}
                        <div className="hidden sm:flex items-center">
                            <div className={`flex items-center space-x-2 px-2 py-1 rounded-full text-sm ${isConnected ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                }`}>
                                <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'
                                    }`} />
                                <span>{isConnected ? 'Live' : 'Offline'}</span>
                            </div>
                        </div>

                        {/* Date & Time */}
                        <div className="hidden lg:block text-sm text-gray-500">
                            {format(new Date(), 'EEE, MMM d, yyyy • h:mm a')}
                        </div>

                        {/* Notifications */}
                        <div className="relative" ref={notificationsRef}>
                            <button
                                onClick={() => setShowNotifications(!showNotifications)}
                                className="relative p-2 text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500 rounded-full"
                            >
                                <FiBell size={20} />
                                {unreadCount > 0 && (
                                    <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
                                        {unreadCount}
                                    </span>
                                )}
                            </button>

                            {/* Notifications Dropdown */}
                            {showNotifications && (
                                <div className="origin-top-right absolute right-0 mt-2 w-80 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-50">
                                    <div className="py-1">
                                        <div className="px-4 py-2 border-b border-gray-200 flex justify-between items-center">
                                            <h3 className="text-sm font-semibold text-gray-900">Notifications</h3>
                                            {unreadCount > 0 && (
                                                <button
                                                    onClick={markAllAsRead}
                                                    className="text-xs text-primary-600 hover:text-primary-800"
                                                >
                                                    Mark all as read
                                                </button>
                                            )}
                                        </div>
                                        <div className="max-h-96 overflow-y-auto">
                                            {notifications.length === 0 ? (
                                                <div className="px-4 py-8 text-center text-gray-500">
                                                    No notifications
                                                </div>
                                            ) : (
                                                notifications.map((notification) => (
                                                    <div
                                                        key={notification.id}
                                                        className={`px-4 py-3 hover:bg-gray-50 cursor-pointer transition-colors ${!notification.read ? 'bg-blue-50' : ''
                                                            }`}
                                                        onClick={() => markAsRead(notification.id)}
                                                    >
                                                        <div className="flex items-start space-x-3">
                                                            <div className="flex-shrink-0">
                                                                {getNotificationIcon(notification.type)}
                                                            </div>
                                                            <div className="flex-1 min-w-0">
                                                                <p className="text-sm font-medium text-gray-900">
                                                                    {notification.title}
                                                                </p>
                                                                <p className="text-sm text-gray-500">
                                                                    {notification.message}
                                                                </p>
                                                                <p className="text-xs text-gray-400 mt-1">
                                                                    {format(notification.time, 'h:mm a')}
                                                                </p>
                                                            </div>
                                                            {!notification.read && (
                                                                <div className="flex-shrink-0">
                                                                    <div className="w-2 h-2 bg-blue-600 rounded-full" />
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                ))
                                            )}
                                        </div>
                                        <div className="px-4 py-2 border-t border-gray-200">
                                            <Link
                                                to="/notifications"
                                                className="block text-center text-sm text-primary-600 hover:text-primary-800"
                                            >
                                                View all notifications
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Help */}
                        <button className="hidden sm:block p-2 text-gray-400 hover:text-gray-500 focus:outline-none">
                            <FiHelpCircle size={20} />
                        </button>

                        {/* User Menu */}
                        <div className="relative" ref={userMenuRef}>
                            <button
                                onClick={() => setShowUserMenu(!showUserMenu)}
                                className="flex items-center space-x-2 focus:outline-none focus:ring-2 focus:ring-primary-500 rounded-full"
                            >
                                <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-full flex items-center justify-center">
                                    <span className="text-white text-sm font-medium">
                                        {user?.name?.charAt(0).toUpperCase() || 'U'}
                                    </span>
                                </div>
                                <div className="hidden lg:block text-left">
                                    <p className="text-sm font-medium text-gray-700">{user?.name || 'User'}</p>
                                    <p className="text-xs text-gray-500 capitalize">{user?.role || 'Role'}</p>
                                </div>
                                <FiChevronDown size={16} className="hidden lg:block text-gray-400" />
                            </button>

                            {/* User Dropdown Menu */}
                            {showUserMenu && (
                                <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-50">
                                    <div className="py-1">
                                        <div className="px-4 py-2 border-b border-gray-200 lg:hidden">
                                            <p className="text-sm font-medium text-gray-900">{user?.name}</p>
                                            <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
                                        </div>
                                        <Link
                                            to="/profile"
                                            className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                            onClick={() => setShowUserMenu(false)}
                                        >
                                            <div className="flex items-center space-x-2">
                                                <FiUser size={16} />
                                                <span>Your Profile</span>
                                            </div>
                                        </Link>
                                        <Link
                                            to="/settings"
                                            className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                            onClick={() => setShowUserMenu(false)}
                                        >
                                            <div className="flex items-center space-x-2">
                                                <FiSettings size={16} />
                                                <span>Settings</span>
                                            </div>
                                        </Link>
                                        <div className="border-t border-gray-200"></div>
                                        <button
                                            onClick={handleLogout}
                                            className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                                        >
                                            <div className="flex items-center space-x-2">
                                                <FiLogOut size={16} />
                                                <span>Sign out</span>
                                            </div>
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;