import React from 'react';
import PropTypes from 'prop-types';

const LoadingSpinner = ({ size = 'medium', text = 'Loading...' }) => {
    const sizeClasses = {
        small: 'w-6 h-6',
        medium: 'w-12 h-12',
        large: 'w-16 h-16'
    };

    return (
        <div className="flex flex-col items-center justify-center">
            <div className={`${sizeClasses[size]} animate-spin rounded-full border-b-2 border-primary-600`} />
            {text && <p className="mt-4 text-gray-600">{text}</p>}
        </div>
    );
};

LoadingSpinner.propTypes = {
    size: PropTypes.oneOf(['small', 'medium', 'large']),
    text: PropTypes.string
};

export default LoadingSpinner;