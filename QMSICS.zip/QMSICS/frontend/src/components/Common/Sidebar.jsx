import React, { useState, useEffect } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@hooks/useAuth';
import { useSocket } from '@hooks/useSocket';
import {
    FiHome, FiUser, FiUsers, FiSettings, FiLogOut, FiMenu, FiX,
    FiChevronRight, FiChevronLeft, FiMonitor, FiGrid, FiMapPin,
    FiClipboard, FiBarChart2, FiClock, FiAlertCircle, FiCheckCircle,
    FiShield, FiActivity, FiPlay, FiList
} from 'react-icons/fi';

const Sidebar = ({ isOpen, onToggle, collapsed, onCollapse }) => {
    const { user, logout } = useAuth();
    const { isConnected } = useSocket();
    const location = useLocation();
    const navigate = useNavigate();
    const [activeDropdown, setActiveDropdown] = useState(null);

    // Navigation items based on user role
    const getNavItems = () => {
        const items = [];

        // Dashboard (All users)
        items.push({
            name: 'Dashboard',
            path: '/dashboard',
            icon: FiHome,
            roles: ['admin', 'super_admin', 'supervisor', 'operator', 'viewer']
        });

        // Admin items
        if (user?.role === 'admin' || user?.role === 'super_admin') {
            items.push({
                name: 'User Management',
                path: '/admin/users',
                icon: FiUsers,
                roles: ['admin', 'super_admin']
            });
            items.push({
                name: 'Role Management',
                path: '/admin/roles',
                icon: FiShield,
                roles: ['admin', 'super_admin']
            });
            items.push({
                name: 'Zone Management',
                path: '/admin/zones',
                icon: FiMapPin,
                roles: ['admin', 'super_admin']
            });
            items.push({
                name: 'Counter Management',
                path: '/admin/counters',
                icon: FiGrid,
                roles: ['admin', 'super_admin']
            });
            items.push({
                name: 'Service Management',
                path: '/admin/services',
                icon: FiClipboard,
                roles: ['admin', 'super_admin']
            });
            items.push({
                name: 'System Config',
                path: '/admin/config',
                icon: FiSettings,
                roles: ['admin', 'super_admin']
            });
            items.push({
                name: 'Audit Logs',
                path: '/admin/audit-logs',
                icon: FiActivity,
                roles: ['admin', 'super_admin']
            });
        }

        // Supervisor items
        if (user?.role === 'supervisor' || user?.role === 'admin' || user?.role === 'super_admin') {
            items.push({
                name: 'Live Monitor',
                path: '/supervisor/monitor',
                icon: FiMonitor,
                roles: ['supervisor', 'admin', 'super_admin']
            });
            items.push({
                name: 'Escalation Panel',
                path: '/supervisor/escalate',
                icon: FiAlertCircle,
                roles: ['supervisor', 'admin', 'super_admin']
            });
            items.push({
                name: 'Performance Reports',
                path: '/supervisor/reports',
                icon: FiBarChart2,
                roles: ['supervisor', 'admin', 'super_admin']
            });
        }

        // Operator items
        if (user?.role === 'operator' || user?.role === 'supervisor' || user?.role === 'admin' || user?.role === 'super_admin') {
            items.push({
                name: 'My Counter',
                path: '/operator',
                icon: FiGrid,
                roles: ['operator', 'supervisor', 'admin', 'super_admin']
            });
            items.push({
                name: 'Call Next',
                path: '/operator/call-next',
                icon: FiPlay,
                roles: ['operator', 'supervisor', 'admin', 'super_admin']
            });
        }

        // Common items (all users)
        items.push({
            name: 'Queue Status',
            path: '/queue',
            icon: FiClock,
            roles: ['admin', 'super_admin', 'supervisor', 'operator', 'viewer']
        });
        items.push({
            name: 'Profile',
            path: '/profile',
            icon: FiUser,
            roles: ['admin', 'super_admin', 'supervisor', 'operator', 'viewer']
        });
        items.push({
            name: 'Settings',
            path: '/settings',
            icon: FiSettings,
            roles: ['admin', 'super_admin', 'supervisor', 'operator', 'viewer']
        });

        return items;
    };

    const navItems = getNavItems();

    const handleLogout = async () => {
        await logout();
        navigate('/login');
    };

    const toggleCollapse = () => {
        onCollapse(!collapsed);
    };

    const isActive = (path) => {
        return location.pathname === path || location.pathname.startsWith(path + '/');
    };

    return (
        <>
            {/* Mobile Menu Button */}
            <button
                onClick={onToggle}
                className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-primary-600 text-white rounded-lg shadow-lg hover:bg-primary-700 transition-colors"
            >
                {isOpen ? <FiX size={20} /> : <FiMenu size={20} />}
            </button>

            {/* Sidebar */}
            <aside
                className={`
          fixed top-0 left-0 h-full bg-gray-900 text-white transition-all duration-300 z-40
          ${collapsed ? 'w-20' : 'w-64'}
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
            >
                {/* Logo Section */}
                <div className={`
          flex items-center justify-between h-16 px-4 border-b border-gray-800
          ${collapsed ? 'justify-center' : ''}
        `}>
                    {!collapsed && (
                        <div className="flex items-center space-x-2">
                            <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-lg flex items-center justify-center">
                                <FiGrid className="text-white" size={18} />
                            </div>
                            <span className="font-bold text-lg">GadaH QMS</span>
                        </div>
                    )}
                    {collapsed && (
                        <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-lg flex items-center justify-center">
                            <FiGrid className="text-white" size={18} />
                        </div>
                    )}
                    <button
                        onClick={toggleCollapse}
                        className="hidden lg:block text-gray-400 hover:text-white transition-colors"
                    >
                        {collapsed ? <FiChevronRight size={18} /> : <FiChevronLeft size={18} />}
                    </button>
                </div>

                {/* User Info Section */}
                <div className={`
          p-4 border-b border-gray-800
          ${collapsed ? 'text-center' : ''}
        `}>
                    <div className={`
            flex items-center
            ${collapsed ? 'justify-center' : 'space-x-3'}
          `}>
                        <div className="relative">
                            <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-full flex items-center justify-center">
                                <span className="text-white font-semibold">
                                    {user?.name?.charAt(0).toUpperCase() || 'U'}
                                </span>
                            </div>
                            <div className={`
                absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-gray-900
                ${isConnected ? 'bg-green-500' : 'bg-red-500'}
              `} />
                        </div>
                        {!collapsed && (
                            <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium truncate">{user?.name || 'User'}</p>
                                <p className="text-xs text-gray-400 truncate capitalize">{user?.role || 'Role'}</p>
                            </div>
                        )}
                    </div>
                </div>

                {/* Navigation Items */}
                <nav className="flex-1 overflow-y-auto py-4 sidebar-scroll">
                    <ul className="space-y-1">
                        {navItems.map((item) => {
                            const Icon = item.icon;
                            const active = isActive(item.path);

                            return (
                                <li key={item.path}>
                                    <NavLink
                                        to={item.path}
                                        className={`
                      flex items-center px-4 py-3 transition-colors duration-200
                      ${active ? 'bg-primary-600 text-white' : 'text-gray-300 hover:bg-gray-800 hover:text-white'}
                      ${collapsed ? 'justify-center' : 'space-x-3'}
                    `}
                                        title={collapsed ? item.name : ''}
                                    >
                                        <Icon size={20} />
                                        {!collapsed && <span className="text-sm">{item.name}</span>}
                                    </NavLink>
                                </li>
                            );
                        })}
                    </ul>
                </nav>

                {/* Footer Section */}
                <div className="border-t border-gray-800 p-4">
                    <button
                        onClick={handleLogout}
                        className={`
              w-full flex items-center text-gray-300 hover:text-white hover:bg-gray-800 rounded-lg transition-colors duration-200
              ${collapsed ? 'justify-center py-2' : 'space-x-3 px-4 py-2'}
            `}
                        title={collapsed ? 'Logout' : ''}
                    >
                        <FiLogOut size={20} />
                        {!collapsed && <span className="text-sm">Logout</span>}
                    </button>
                </div>
            </aside>

            {/* Overlay for mobile */}
            {isOpen && (
                <div
                    className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
                    onClick={onToggle}
                />
            )}
        </>
    );
};

export default Sidebar;