@echo off
title GadaH Queue Management System - Advanced Setup
color 0E

:: Set variables
set PROJECT_NAME=GadaH_QMS
set BACKEND_DIR=backend
set FRONTEND_DIR=frontend
set MONGO_DB=GadaH
set ADMIN_EMAIL=admin@gadah.com
set ADMIN_PASS=admin123

:: Check for administrator privileges
net session >nul 2>&1
if %errorLevel% == 0 (
    echo Running with administrator privileges
    set ADMIN_MODE=true
) else (
    echo Running in user mode
    set ADMIN_MODE=false
)

:menu
cls
echo ╔══════════════════════════════════════════════════════════════╗
echo ║                G A D A H   Q U E U E   S Y S T E M           ║
echo ║                     Advanced Setup Menu                      ║
echo ╠══════════════════════════════════════════════════════════════╣
echo ║ 1. Complete Installation (Recommended)                       ║
echo ║ 2. Install Only Backend Dependencies                         ║
echo ║ 3. Install Only Frontend Dependencies                        ║
echo ║ 4. Initialize/Reset GadaH Database                           ║
echo ║ 5. Check System Status                                       ║
echo ║ 6. Start GadaH System (Development Mode)                     ║
echo ║ 7. Build for Production                                      ║
echo ║ 8. Run Database Backup                                       ║
echo ║ 9. Exit                                                      ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.
set /p choice="Enter your choice (1-9): "

if "%choice%"=="1" goto complete_install
if "%choice%"=="2" goto install_backend
if "%choice%"=="3" goto install_frontend
if "%choice%"=="4" goto init_database
if "%choice%"=="5" goto check_status
if "%choice%"=="6" goto start_system
if "%choice%"=="7" goto build_production
if "%choice%"=="8" goto backup_database
if "%choice%"=="9" goto exit
goto menu

:complete_install
cls
echo ========================================
echo   GadaH System - Complete Installation
echo ========================================
echo.

call :check_node
if %errorlevel% neq 0 goto :error

call :install_backend
if %errorlevel% neq 0 goto :error

call :install_frontend
if %errorlevel% neq 0 goto :error

call :check_mongodb
if %errorlevel% neq 0 goto :error

call :init_database
if %errorlevel% neq 0 goto :error

goto :complete_success

:install_backend
cls
echo ========================================
echo   Installing Backend Dependencies
echo ========================================
echo.

if not exist "%BACKEND_DIR%" (
    echo ❌ Backend directory not found: %BACKEND_DIR%
    pause
    exit /b 1
)

cd %BACKEND_DIR%
echo Installing Node.js packages...
call npm install --silent
if %errorlevel% neq 0 (
    echo ❌ Backend installation failed
    cd ..
    pause
    exit /b 1
)

echo ✅ Backend dependencies installed
echo.
echo Installed packages:
call npm list --depth=0
cd ..
pause
goto menu

:install_frontend
cls
echo ========================================
echo   Installing Frontend Dependencies
echo ========================================
echo.

if not exist "%FRONTEND_DIR%" (
    echo ❌ Frontend directory not found: %FRONTEND_DIR%
    pause
    exit /b 1
)

cd %FRONTEND_DIR%
echo Installing Node.js packages...
call npm install --silent
if %errorlevel% neq 0 (
    echo ❌ Frontend installation failed
    cd ..
    pause
    exit /b 1
)

echo ✅ Frontend dependencies installed
echo.
echo Installed packages:
call npm list --depth=0
cd ..
pause
goto menu

:check_mongodb
cls
echo ========================================
echo   Checking MongoDB Connection
echo ========================================
echo.

echo Testing connection to %MONGO_DB% database...
cd %BACKEND_DIR%

node -e "const mongoose = require('mongoose'); mongoose.connect('mongodb://localhost:27017/%MONGO_DB%', { serverSelectionTimeoutMS: 5000 }).then(() => { console.log('✅ Connected to %MONGO_DB% Database'); process.exit(0); }).catch(err => { console.error('❌ Connection failed:', err.message); process.exit(1); });"

if %errorlevel% neq 0 (
    echo.
    echo ⚠️  MongoDB is not running or %MONGO_DB% database not accessible
    echo.
    echo Please start MongoDB:
    if "%ADMIN_MODE%"=="true" (
        echo   Starting MongoDB service...
        net start MongoDB >nul 2>&1
        if %errorlevel% equ 0 (
            echo ✅ MongoDB service started
            timeout /t 3 /nobreak >nul
            goto :check_mongodb
        ) else (
            echo ❌ Could not start MongoDB service automatically
        )
    )
    echo.
    echo Manual steps:
    echo   1. Open Command Prompt as Administrator
    echo   2. Run: net start MongoDB
    echo   3. Or start MongoDB manually: "C:\Program Files\MongoDB\Server\7.0\bin\mongod.exe"
    echo.
    cd ..
    pause
    exit /b 1
)

echo ✅ MongoDB is running and %MONGO_DB% database is ready
cd ..
pause
goto menu

:init_database
cls
echo ========================================
echo   Initializing GadaH Database
echo ========================================
echo.

cd %BACKEND_DIR%
echo Creating system data, roles, privileges, and admin user...

:: Check if init-system script exists
if not exist "node_modules\.bin\nodemon" (
    echo Installing nodemon...
    call npm install --save-dev nodemon
)

call npm run init-system
if %errorlevel% neq 0 (
    echo ❌ Database initialization failed
    cd ..
    pause
    exit /b 1
)

echo ✅ GadaH Database initialized successfully
cd ..
pause
goto menu

:check_status
cls
echo ========================================
echo   GadaH System Status Check
echo ========================================
echo.

:: Check Node.js
echo [1] Node.js:
node --version
echo.

:: Check MongoDB
echo [2] MongoDB Connection:
cd %BACKEND_DIR%
node -e "const mongoose = require('mongoose'); mongoose.connect('mongodb://localhost:27017/%MONGO_DB%').then(() => { console.log('✅ Connected to %MONGO_DB%'); process.exit(0); }).catch(err => { console.log('❌ Not connected'); process.exit(1); });"
if %errorlevel% neq 0 (
    echo ❌ MongoDB is not running
) else (
    echo ✅ MongoDB is running
)
cd ..
echo.

:: Check Backend Dependencies
echo [3] Backend Dependencies:
cd %BACKEND_DIR%
if exist "node_modules" (
    echo ✅ Node modules installed
    call npm list --depth=0 --parseable >nul 2>&1
    if %errorlevel% equ 0 (
        echo ✅ All packages OK
    )
) else (
    echo ❌ Node modules not found
)
cd ..
echo.

:: Check Frontend Dependencies
echo [4] Frontend Dependencies:
cd %FRONTEND_DIR%
if exist "node_modules" (
    echo ✅ Node modules installed
) else (
    echo ❌ Node modules not found
)
cd ..
echo.

:: Check Environment Files
echo [5] Environment Configuration:
if exist "%BACKEND_DIR%\.env" (
    echo ✅ Backend .env exists
) else (
    echo ⚠️  Backend .env not found (create from .env.example)
)

if exist "%FRONTEND_DIR%\.env" (
    echo ✅ Frontend .env exists
) else (
    echo ⚠️  Frontend .env not found (create from .env.example)
)
echo.

:: Check Ports
echo [6] Port Status:
netstat -an | findstr :5000 >nul
if %errorlevel% equ 0 (
    echo ⚠️  Port 5000 is in use (Backend)
) else (
    echo ✅ Port 5000 is available
)

netstat -an | findstr :3000 >nul
if %errorlevel% equ 0 (
    echo ⚠️  Port 3000 is in use (Frontend)
) else (
    echo ✅ Port 3000 is available
)
echo.

pause
goto menu

:start_system
cls
echo ========================================
echo   Starting GadaH System
echo ========================================
echo.

echo Starting Backend Server...
start "GadaH Backend" cmd /k "cd %BACKEND_DIR% && npm run dev"

echo Waiting for backend to start...
timeout /t 5 /nobreak >nul

echo Starting Frontend Application...
start "GadaH Frontend" cmd /k "cd %FRONTEND_DIR% && npm run dev"

echo.
echo ========================================
echo   GadaH System Started!
echo ========================================
echo.
echo Backend:  http://localhost:5000
echo Frontend: http://localhost:3000
echo Health:   http://localhost:5000/health
echo.
echo Login with: admin@gadah.com / admin123
echo.
pause
goto menu

:build_production
cls
echo ========================================
echo   Building GadaH for Production
echo ========================================
echo.

echo Building Frontend...
cd %FRONTEND_DIR%
call npm run build
if %errorlevel% neq 0 (
    echo ❌ Frontend build failed
    cd ..
    pause
    goto menu
)
echo ✅ Frontend build completed
cd ..

echo.
echo ========================================
echo   Production Build Complete
echo ========================================
echo.
echo Frontend build output: %FRONTEND_DIR%\dist
echo.
echo To run in production:
echo   Backend:  cd backend && npm start
echo   Frontend: Serve the dist folder with nginx or similar
echo.
pause
goto menu

:backup_database
cls
echo ========================================
echo   GadaH Database Backup
echo ========================================
echo.

set BACKUP_DIR=backups
if not exist "%BACKUP_DIR%" mkdir %BACKUP_DIR%

set BACKUP_NAME=gadah_backup_%date:~-4,4%%date:~-10,2%%date:~-7,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set BACKUP_NAME=%BACKUP_NAME: =0%

echo Backing up %MONGO_DB% database...

mongodump --db %MONGO_DB% --out "%BACKUP_DIR%\%BACKUP_NAME%"

if %errorlevel% equ 0 (
    echo ✅ Database backup completed: %BACKUP_DIR%\%BACKUP_NAME%
) else (
    echo ❌ Backup failed. Make sure mongodump is in PATH
    echo Install MongoDB Tools: https://www.mongodb.com/try/download/database-tools
)

pause
goto menu

:complete_success
cls
echo.
echo ╔══════════════════════════════════════════════════════════════╗
echo ║            G A D A H   S Y S T E M   R E A D Y               ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.
echo ╔══════════════════════════════════════════════════════════════╗
echo ║                    SYSTEM INFORMATION                        ║
echo ╠══════════════════════════════════════════════════════════════╣
echo ║ System Name:     GadaH Queue Management System               ║
echo ║ Database:        %MONGO_DB%                                   ║
echo ║ Admin Email:     %ADMIN_EMAIL%                                ║
echo ║ Admin Password:  %ADMIN_PASS%                                 ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.
echo ╔══════════════════════════════════════════════════════════════╗
echo ║                    QUICK START GUIDE                         ║
echo ╠══════════════════════════════════════════════════════════════╣
echo ║ 1. Start Backend Server:                                     ║
echo ║    cd backend && npm run dev                                 ║
echo ║                                                              ║
echo ║ 2. Start Frontend Application:                               ║
echo ║    cd frontend && npm run dev                                ║
echo ║                                                              ║
echo ║ 3. Access the System:                                        ║
echo ║    Web: http://localhost:3000                                ║
echo ║    API: http://localhost:5000                                ║
echo ║                                                              ║
echo ║ 4. Login with:                                               ║
echo ║    Email: admin@gadah.com                                    ║
echo ║    Password: admin123                                        ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.
echo ╔══════════════════════════════════════════════════════════════╗
echo ║                    USEFUL COMMANDS                           ║
echo ╠══════════════════════════════════════════════════════════════╣
echo ║ View Logs:        cd backend && tail -f logs/application.log  ║
echo ║ Reset Database:   cd backend && npm run init-system          ║
echo ║ Run Tests:        cd backend && npm test                      ║
echo ║ Lint Code:        cd backend && npm run lint                  ║
echo ║ Format Code:      cd backend && npm run format                ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.
echo Press any key to return to menu...
pause >nul
goto menu

:check_node
echo Checking Node.js installation...
node --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Node.js is not installed or not in PATH
    echo.
    echo Please install Node.js from: https://nodejs.org/
    echo Recommended version: 18.x or higher
    echo.
    pause
    exit /b 1
)
echo ✅ Node.js version: 
node --version
echo.
exit /b 0

:error
echo.
echo ========================================
echo   ❌ Installation Failed
echo ========================================
echo.
echo Please check the error messages above.
echo.
echo Common issues:
echo   1. Internet connection problem
echo   2. Node.js version too old (need 18+)
echo   3. MongoDB not installed or not running
echo   4. Port conflicts (5000 or 3000 in use)
echo.
pause
goto menu

:exit
echo.
echo Thank you for using GadaH Queue Management System!
echo.
exit