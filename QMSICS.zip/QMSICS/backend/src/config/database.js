const mongoose = require('mongoose');
const logger = require('../utils/logger');

class Database {
    constructor() {
        this.isConnected = false;
        this.connection = null;
        this.retryCount = 0;
        this.maxRetries = 5;
    }

    async connect() {
        try {
            // Check if already connected
            if (this.isConnected && mongoose.connection.readyState === 1) {
                logger.info('Using existing database connection');
                return this.connection;
            }

            // Get MongoDB URI from environment
            const mongoURI = process.env.MONGODB_URI;

            if (!mongoURI) {
                throw new Error('MONGODB_URI is not defined in environment variables');
            }

            // Connection options
            const options = {
                useNewUrlParser: true,
                useUnifiedTopology: true,
                maxPoolSize: 10,
                minPoolSize: 2,
                serverSelectionTimeoutMS: 5000,
                socketTimeoutMS: 45000,
                family: 4,
                retryWrites: true,
                retryReads: true,
            };

            // Log connection attempt (hide credentials)
            const sanitizedURI = mongoURI.replace(/\/\/([^:]+):([^@]+)@/, '//***:***@');
            logger.info(`Connecting to GadaH Database...`);
            logger.info(`MongoDB URI: ${sanitizedURI}`);

            // Attempt connection
            this.connection = await mongoose.connect(mongoURI, options);
            this.isConnected = true;
            this.retryCount = 0;

            // Log successful connection
            logger.info(`✅ GadaH Database Connected Successfully`);
            logger.info(`📊 Database Name: ${mongoose.connection.name}`);
            logger.info(`🔗 Host: ${mongoose.connection.host}`);
            logger.info(`🔌 Port: ${mongoose.connection.port}`);
            logger.info(`📦 Models Loaded: ${Object.keys(mongoose.models).length}`);
            logger.info(`📋 Models: ${Object.keys(mongoose.models).join(', ')}`);

            // Setup event handlers
            this._setupEventHandlers();

            return this.connection;

        } catch (error) {
            logger.error(`❌ GadaH Database Connection Failed: ${error.message}`);
            this.isConnected = false;

            // Retry logic for connection failures
            if (this.retryCount < this.maxRetries) {
                this.retryCount++;
                const delay = Math.min(1000 * Math.pow(2, this.retryCount), 10000);
                logger.warn(`Retrying connection in ${delay}ms (Attempt ${this.retryCount}/${this.maxRetries})...`);

                await new Promise(resolve => setTimeout(resolve, delay));
                return this.connect();
            }

            throw error;
        }
    }

    _setupEventHandlers() {
        // Connection error handler
        mongoose.connection.on('error', (err) => {
            logger.error(`GadaH Database connection error: ${err.message}`);
            this.isConnected = false;
        });

        // Disconnection handler
        mongoose.connection.on('disconnected', () => {
            logger.warn('⚠️ GadaH Database disconnected');
            this.isConnected = false;

            // Auto-reconnect in development
            if (process.env.NODE_ENV !== 'production') {
                logger.info('Attempting to reconnect...');
                setTimeout(() => this.connect(), 5000);
            }
        });

        // Reconnection handler
        mongoose.connection.on('reconnected', () => {
            logger.info('✅ GadaH Database reconnected successfully');
            this.isConnected = true;
        });

        // Connection ready handler
        mongoose.connection.on('connected', () => {
            logger.info('GadaH Database connection established');
        });

        // Handle application termination
        process.on('SIGINT', async () => {
            await this.disconnect();
            process.exit(0);
        });
    }

    async disconnect() {
        try {
            if (this.isConnected && mongoose.connection.readyState === 1) {
                await mongoose.disconnect();
                this.isConnected = false;
                this.connection = null;
                logger.info('✅ GadaH Database disconnected successfully');
            } else {
                logger.info('No active database connection to disconnect');
            }
        } catch (error) {
            logger.error(`❌ Error disconnecting GadaH Database: ${error.message}`);
            throw error;
        }
    }

    getConnectionStatus() {
        const states = {
            0: 'disconnected',
            1: 'connected',
            2: 'connecting',
            3: 'disconnecting',
            99: 'uninitialized'
        };

        const state = mongoose.connection.readyState;
        const status = states[state] || 'unknown';

        return {
            state: state,
            status: status,
            isConnected: state === 1,
            host: mongoose.connection.host,
            database: mongoose.connection.name,
            models: Object.keys(mongoose.models)
        };
    }

    async healthCheck() {
        try {
            // Ping the database
            await mongoose.connection.db.admin().ping();

            // Get database stats
            const stats = await mongoose.connection.db.stats();

            return {
                status: 'healthy',
                message: 'GadaH Database is responsive',
                details: {
                    database: mongoose.connection.name,
                    collections: stats.collections,
                    objects: stats.objects,
                    avgObjSize: stats.avgObjSize,
                    dataSize: stats.dataSize,
                    storageSize: stats.storageSize,
                    indexes: stats.indexes,
                    indexSize: stats.indexSize
                }
            };
        } catch (error) {
            return {
                status: 'unhealthy',
                message: error.message,
                details: null
            };
        }
    }

    async getDatabaseInfo() {
        try {
            const collections = await mongoose.connection.db.listCollections().toArray();
            const stats = await mongoose.connection.db.stats();

            return {
                name: mongoose.connection.name,
                host: mongoose.connection.host,
                port: mongoose.connection.port,
                collections: collections.map(c => c.name),
                stats: {
                    collections: stats.collections,
                    objects: stats.objects,
                    dataSize: (stats.dataSize / 1024 / 1024).toFixed(2) + ' MB',
                    storageSize: (stats.storageSize / 1024 / 1024).toFixed(2) + ' MB',
                    indexes: stats.indexes
                }
            };
        } catch (error) {
            logger.error(`Failed to get database info: ${error.message}`);
            return null;
        }
    }

    async clearDatabase() {
        if (process.env.NODE_ENV === 'production') {
            throw new Error('Cannot clear database in production environment');
        }

        try {
            const collections = mongoose.connection.collections;

            for (const key in collections) {
                await collections[key].deleteMany({});
                logger.info(`Cleared collection: ${key}`);
            }

            logger.info('✅ Database cleared successfully');
            return true;
        } catch (error) {
            logger.error(`Error clearing database: ${error.message}`);
            throw error;
        }
    }
}

// Export singleton instance
module.exports = new Database();