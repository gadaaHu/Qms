const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
    getLiveDashboard,
    escalateTicket,
    reorderQueue,
    getCountersStatus,
    getPerformanceMetrics,
    getSLACompliance
} = require('../controllers/supervisorController');

router.use(protect);
router.use(authorize('supervisor', 'admin'));

router.get('/dashboard', getLiveDashboard);
router.get('/counters', getCountersStatus);
router.get('/performance', getPerformanceMetrics);
router.get('/sla', getSLACompliance);
router.post('/escalate', escalateTicket);
router.post('/reorder', reorderQueue);

module.exports = router;