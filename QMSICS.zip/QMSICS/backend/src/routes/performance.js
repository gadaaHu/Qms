const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
    getMetrics,
    generateReport,
    exportReport,
    getPeakHours
} = require('../controllers/performanceController');

router.use(protect);
router.use(authorize('supervisor', 'admin'));

router.get('/', getMetrics);
router.get('/peak-hours', getPeakHours);
router.get('/export', exportReport);
router.post('/report', generateReport);

module.exports = router;