const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
    getConfigurations,
    getConfigByKey,
    updateConfiguration,
    bulkUpdateConfigurations,
    resetConfiguration,
    getServices,
    createService,
    updateService,
    deleteService
} = require('../controllers/baseDataController');

// Configuration routes
router.get('/configurations', protect, authorize('admin', 'supervisor'), getConfigurations);
router.get('/configurations/:key', protect, authorize('admin', 'supervisor'), getConfigByKey);
router.put('/configurations/:key', protect, authorize('admin'), updateConfiguration);
router.post('/configurations/bulk', protect, authorize('admin'), bulkUpdateConfigurations);
router.post('/configurations/:key/reset', protect, authorize('admin'), resetConfiguration);

// Service routes
router.get('/services', protect, getServices);
router.post('/services', protect, authorize('admin'), createService);
router.put('/services/:id', protect, authorize('admin'), updateService);
router.delete('/services/:id', protect, authorize('admin'), deleteService);

module.exports = router;