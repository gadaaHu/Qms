const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
    getConfig,
    updateConfig,
    bulkUpdateConfig,
    getConfigGroups
} = require('../controllers/configController');

const {
    getRoles,
    getRole,
    createRole,
    updateRole,
    deleteRole,
    getPrivileges,
    createPrivilege,
    updatePrivilege,
    deletePrivilege,
    getPrivilegeModules
} = require('../controllers/roleController');

// Protect all routes
router.use(protect);
router.use(authorize('admin'));

// Role management
router.get('/roles', getRoles);
router.get('/roles/:id', getRole);
router.post('/roles', createRole);
router.put('/roles/:id', updateRole);
router.delete('/roles/:id', deleteRole);

// Privilege management
router.get('/privileges', getPrivileges);
router.get('/privileges/modules', getPrivilegeModules);
router.post('/privileges', createPrivilege);
router.put('/privileges/:id', updatePrivilege);
router.delete('/privileges/:id', deletePrivilege);

// System configuration
router.get('/config', getConfig);
router.get('/config/groups', getConfigGroups);
router.put('/config/:key', updateConfig);
router.post('/config/bulk', bulkUpdateConfig);

module.exports = router;