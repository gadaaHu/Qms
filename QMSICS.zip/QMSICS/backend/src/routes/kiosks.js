const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
    getKiosks,
    getKiosk,
    createKiosk,
    updateKiosk,
    deleteKiosk,
    heartbeat,
    updateKioskConfig,
    getKioskStats
} = require('../controllers/kioskController');

// Public routes (for kiosk devices)
router.post('/:id/heartbeat', heartbeat);

// Protected routes
router.use(protect);

router.get('/', getKiosks);
router.get('/stats', getKioskStats);
router.get('/:id', getKiosk);

// Admin only
router.post('/', authorize('admin'), createKiosk);
router.put('/:id', authorize('admin'), updateKiosk);
router.delete('/:id', authorize('admin'), deleteKiosk);
router.patch('/:id/config', authorize('admin'), updateKioskConfig);

module.exports = router;