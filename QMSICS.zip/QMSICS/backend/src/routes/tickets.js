const express = require('express');
const {
    createTicket,
    getQueueStatus,
    getTickets,
    getTicketById,
    updateTicketStatus,
    rateTicket
} = require('../controllers/ticketController');
const { protect } = require('../middleware/auth');
const router = express.Router();

router.post('/', createTicket);
router.get('/queue', getQueueStatus);
router.get('/', protect, getTickets);
router.get('/:id', protect, getTicketById);
router.put('/:id/status', protect, updateTicketStatus);
router.post('/:id/rate', rateTicket);

module.exports = router;