const express = require('express');
const { getCounters, createCounter, callNext, completeService } = require('../controllers/counterController');
const { protect, authorize } = require('../middleware/auth');
const router = express.Router();

router.get('/', protect, getCounters);
router.post('/', protect, authorize('admin'), createCounter);
router.post('/:counterId/call', protect, authorize('operator', 'supervisor'), callNext);
router.post('/:counterId/complete/:ticketId', protect, authorize('operator'), completeService);

module.exports = router;