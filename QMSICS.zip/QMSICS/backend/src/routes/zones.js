const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
    getZones,
    getZone,
    createZone,
    updateZone,
    deleteZone,
    assignCounters,
    getZoneStats,
    toggleZoneStatus
} = require('../controllers/zoneController');

router.use(protect);

router.get('/', getZones);
router.get('/:id', getZone);
router.get('/:id/stats', getZoneStats);

// Admin only routes
router.post('/', authorize('admin'), createZone);
router.put('/:id', authorize('admin'), updateZone);
router.delete('/:id', authorize('admin'), deleteZone);
router.post('/:id/assign-counters', authorize('admin'), assignCounters);
router.patch('/:id/toggle-status', authorize('admin'), toggleZoneStatus);

module.exports = router;