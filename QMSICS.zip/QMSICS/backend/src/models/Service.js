const mongoose = require('mongoose');

const serviceSchema = new mongoose.Schema({
    name: { type: String, required: true },
    code: { type: String, required: true, unique: true },
    description: String,
    estimatedDuration: { type: Number, default: 5 },
    isPriority: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    color: { type: String, default: '#667eea' },
}, { timestamps: true });

module.exports = mongoose.model('Service', serviceSchema);