const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    password: { type: String, required: true, select: false },
    role: { type: mongoose.Schema.Types.ObjectId, ref: 'Role', required: true },
    customPermissions: [{ type: String }], // Override role permissions
    zone: { type: mongoose.Schema.Types.ObjectId, ref: 'Zone' },
    counters: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Counter' }],
    status: { type: String, enum: ['active', 'inactive', 'suspended'], default: 'active' },
    lastLogin: Date,
    lastIp: String,
    preferences: {
        language: { type: String, default: 'en' },
        theme: { type: String, default: 'light' },
        notifications: { type: Boolean, default: true }
    },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 12);
    next();
});

userSchema.methods.comparePassword = async function (candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

userSchema.methods.hasPermission = async function (permissionCode) {
    // Check custom permissions first
    if (this.customPermissions && this.customPermissions.includes(permissionCode)) {
        return true;
    }

    // Check role permissions
    const Role = mongoose.model('Role');
    const role = await Role.findById(this.role).populate('privileges');
    if (role && role.privileges) {
        return role.privileges.some(p => p.code === permissionCode);
    }

    return false;
};

module.exports = mongoose.model('User', userSchema);