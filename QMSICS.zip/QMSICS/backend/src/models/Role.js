const mongoose = require('mongoose');

const roleSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true },
    code: { type: String, required: true, unique: true },
    description: String,
    privileges: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Privilege'
    }],
    isSystem: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    level: { type: Number, default: 0 }, // 0-100, higher = more permissions
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Role', roleSchema);