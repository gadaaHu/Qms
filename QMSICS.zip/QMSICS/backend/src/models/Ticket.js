const mongoose = require('mongoose');

const ticketSchema = new mongoose.Schema({
    number: { type: String, required: true, unique: true },
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true },
    customerName: { type: String, default: 'Walk-in Customer' },
    customerPhone: String,
    customerEmail: String,
    priority: { type: String, enum: ['normal', 'priority', 'emergency'], default: 'normal' },
    status: {
        type: String,
        enum: ['waiting', 'called', 'in_service', 'completed', 'cancelled'],
        default: 'waiting'
    },
    zone: { type: mongoose.Schema.Types.ObjectId, ref: 'Zone' },
    counter: { type: mongoose.Schema.Types.ObjectId, ref: 'Counter' },
    operator: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    issuedAt: { type: Date, default: Date.now },
    calledAt: Date,
    startedAt: Date,
    completedAt: Date,
    estimatedWaitTime: Number,
    actualWaitTime: Number,
    serviceTime: Number,
    rating: { type: Number, min: 1, max: 5 },
    feedback: String,
}, { timestamps: true });

ticketSchema.index({ status: 1, priority: -1, issuedAt: 1 });

module.exports = mongoose.model('Ticket', ticketSchema);