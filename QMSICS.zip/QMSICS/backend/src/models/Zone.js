const mongoose = require('mongoose');

const zoneSchema = new mongoose.Schema({
    name: { type: String, required: true },
    code: { type: String, required: true, unique: true },
    description: String,
    location: {
        floor: String,
        building: String,
        coordinates: {
            lat: Number,
            lng: Number
        }
    },
    settings: {
        allowPriority: { type: Boolean, default: true },
        maxQueueLength: { type: Number, default: 50 },
        displaySettings: {
            screenLayout: { type: String, default: 'default' },
            theme: { type: String, default: 'light' }
        }
    },
    assignedCounters: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Counter' }],
    assignedUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    isActive: { type: Boolean, default: true },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Zone', zoneSchema);