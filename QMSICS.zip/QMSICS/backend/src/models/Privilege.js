const mongoose = require('mongoose');

const privilegeSchema = new mongoose.Schema({
    name: { type: String, required: true },
    code: { type: String, required: true, unique: true },
    module: { type: String, required: true },
    description: String,
    category: {
        type: String,
        enum: ['user', 'ticket', 'counter', 'zone', 'service', 'report', 'system', 'settings'],
        required: true
    },
    actions: [{
        type: String,
        enum: ['create', 'read', 'update', 'delete', 'manage', 'assign', 'approve', 'export'],
        required: true
    }],
    isActive: { type: Boolean, default: true },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Privilege', privilegeSchema);