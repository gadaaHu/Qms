const mongoose = require('mongoose');

const counterSchema = new mongoose.Schema({
    name: { type: String, required: true },
    code: { type: String, required: true, unique: true },
    zone: { type: mongoose.Schema.Types.ObjectId, ref: 'Zone', required: true },
    services: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Service' }],
    operator: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    status: { type: String, enum: ['active', 'inactive', 'break'], default: 'active' },
    currentTicket: { type: mongoose.Schema.Types.ObjectId, ref: 'Ticket' },
    servingTicket: { type: mongoose.Schema.Types.ObjectId, ref: 'Ticket' },
    totalServed: { type: Number, default: 0 },
    averageServiceTime: { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model('Counter', counterSchema);