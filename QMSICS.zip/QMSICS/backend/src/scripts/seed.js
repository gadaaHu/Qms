const mongoose = require('mongoose');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');
dotenv.config();

const User = require('../models/User');
const Service = require('../models/Service');
const Zone = require('../models/Zone');
const Counter = require('../models/Counter');

const seed = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('Connected to GadaH Database');

        // Clear existing data
        await User.deleteMany();
        await Service.deleteMany();
        await Zone.deleteMany();
        await Counter.deleteMany();

        console.log('Cleared existing data from GadaH Database');

        // Create admin user
        const adminPassword = await bcrypt.hash('admin123', 12);
        const admin = await User.create({
            name: 'System Administrator',
            email: 'admin@gadah.com',
            password: adminPassword,
            role: 'admin',
            status: 'active'
        });
        console.log('✅ Admin created for GadaH System');

        // Create services
        const services = await Service.create([
            { name: 'General Service', code: 'G', estimatedDuration: 5, color: '#667eea' },
            { name: 'Priority Service', code: 'P', estimatedDuration: 3, isPriority: true, color: '#f59e0b' },
            { name: 'Information Desk', code: 'I', estimatedDuration: 2, color: '#10b981' },
            { name: 'Payment Services', code: 'PY', estimatedDuration: 7, color: '#ef4444' }
        ]);
        console.log(`✅ ${services.length} services created in GadaH Database`);

        // Create zone
        const zone = await Zone.create({
            name: 'Main Hall',
            code: 'MH',
            description: 'Main service area for GadaH'
        });
        console.log('✅ Zone created in GadaH Database');

        // Create counters
        await Counter.create([
            { name: 'Counter 1', code: 'C1', zone: zone._id, services: [services[0]._id, services[1]._id] },
            { name: 'Counter 2', code: 'C2', zone: zone._id, services: [services[0]._id] },
            { name: 'Counter 3', code: 'C3', zone: zone._id, services: [services[2]._id, services[3]._id] }
        ]);
        console.log('✅ Counters created in GadaH Database');

        console.log('\n🎉 GadaH Database seeded successfully!');
        console.log('📝 Login credentials for GadaH System:');
        console.log('   Email: admin@gadah.com');
        console.log('   Password: admin123');

        process.exit(0);
    } catch (error) {
        console.error('Error seeding GadaH Database:', error);
        process.exit(1);
    }
};

seed();