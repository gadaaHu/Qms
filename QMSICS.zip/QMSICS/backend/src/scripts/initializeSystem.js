const mongoose = require('mongoose');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');
dotenv.config();

const User = require('../models/User');
const Role = require('../models/Role');
const Privilege = require('../models/Privilege');
const Configuration = require('../models/Configuration');
const Service = require('../models/Service');
const Zone = require('../models/Zone');

// Define all privileges
const privileges = [
    // User Management
    { name: 'View Users', code: 'user:read', module: 'users', category: 'user', actions: ['read'] },
    { name: 'Create Users', code: 'user:create', module: 'users', category: 'user', actions: ['create'] },
    { name: 'Edit Users', code: 'user:update', module: 'users', category: 'user', actions: ['update'] },
    { name: 'Delete Users', code: 'user:delete', module: 'users', category: 'user', actions: ['delete'] },
    { name: 'Manage Roles', code: 'user:manage_roles', module: 'users', category: 'user', actions: ['manage'] },

    // Ticket Management
    { name: 'View Tickets', code: 'ticket:read', module: 'tickets', category: 'ticket', actions: ['read'] },
    { name: 'Create Tickets', code: 'ticket:create', module: 'tickets', category: 'ticket', actions: ['create'] },
    { name: 'Update Tickets', code: 'ticket:update', module: 'tickets', category: 'ticket', actions: ['update'] },
    { name: 'Call Tickets', code: 'ticket:call', module: 'tickets', category: 'ticket', actions: ['update'] },
    { name: 'Complete Tickets', code: 'ticket:complete', module: 'tickets', category: 'ticket', actions: ['update'] },

    // Counter Management
    { name: 'View Counters', code: 'counter:read', module: 'counters', category: 'counter', actions: ['read'] },
    { name: 'Create Counters', code: 'counter:create', module: 'counters', category: 'counter', actions: ['create'] },
    { name: 'Edit Counters', code: 'counter:update', module: 'counters', category: 'counter', actions: ['update'] },
    { name: 'Delete Counters', code: 'counter:delete', module: 'counters', category: 'counter', actions: ['delete'] },

    // Zone Management
    { name: 'View Zones', code: 'zone:read', module: 'zones', category: 'zone', actions: ['read'] },
    { name: 'Create Zones', code: 'zone:create', module: 'zones', category: 'zone', actions: ['create'] },
    { name: 'Edit Zones', code: 'zone:update', module: 'zones', category: 'zone', actions: ['update'] },
    { name: 'Delete Zones', code: 'zone:delete', module: 'zones', category: 'zone', actions: ['delete'] },

    // Service Management
    { name: 'View Services', code: 'service:read', module: 'services', category: 'service', actions: ['read'] },
    { name: 'Create Services', code: 'service:create', module: 'services', category: 'service', actions: ['create'] },
    { name: 'Edit Services', code: 'service:update', module: 'services', category: 'service', actions: ['update'] },
    { name: 'Delete Services', code: 'service:delete', module: 'services', category: 'service', actions: ['delete'] },

    // Reports
    { name: 'View Reports', code: 'report:read', module: 'reports', category: 'report', actions: ['read'] },
    { name: 'Export Reports', code: 'report:export', module: 'reports', category: 'report', actions: ['export'] },
    { name: 'View Analytics', code: 'report:analytics', module: 'reports', category: 'report', actions: ['read'] },

    // System Settings
    { name: 'View System Settings', code: 'system:read', module: 'system', category: 'system', actions: ['read'] },
    { name: 'Edit System Settings', code: 'system:update', module: 'system', category: 'system', actions: ['update'] },
];

// Define roles with their privileges
const roles = [
    {
        name: 'Super Admin',
        code: 'super_admin',
        description: 'Full system access with all privileges',
        level: 100,
        isSystem: true,
        privileges: [] // Will be populated with all privileges
    },
    {
        name: 'Administrator',
        code: 'admin',
        description: 'System administrator with most privileges',
        level: 90,
        isSystem: true,
        privileges: [] // Will be populated with most privileges
    },
    {
        name: 'Supervisor',
        code: 'supervisor',
        description: 'Can manage queues, view reports, and handle escalations',
        level: 70,
        isSystem: true,
        privileges: [
            'ticket:read', 'ticket:create', 'ticket:update', 'ticket:call', 'ticket:complete',
            'counter:read', 'counter:manage_status',
            'zone:read',
            'service:read',
            'report:read', 'report:analytics'
        ]
    },
    {
        name: 'Operator',
        code: 'operator',
        description: 'Can manage tickets at assigned counters',
        level: 50,
        isSystem: true,
        privileges: [
            'ticket:read', 'ticket:create', 'ticket:call', 'ticket:complete',
            'counter:read',
            'service:read'
        ]
    },
    {
        name: 'Viewer',
        code: 'viewer',
        description: 'Read-only access to view queues and status',
        level: 10,
        isSystem: true,
        privileges: [
            'ticket:read',
            'counter:read',
            'zone:read',
            'service:read',
            'report:read'
        ]
    }
];

// System configurations
const configurations = [
    // System Settings
    { key: 'system.name', value: 'GadaH Queue Management System', category: 'system', group: 'general', type: 'string' },
    { key: 'system.timezone', value: 'UTC', category: 'system', group: 'general', type: 'string' },
    { key: 'system.date_format', value: 'YYYY-MM-DD', category: 'system', group: 'general', type: 'string' },

    // Queue Settings
    { key: 'queue.ticket_prefix', value: 'GDA', category: 'queue', group: 'tickets', type: 'string' },
    { key: 'queue.max_waiting', value: 50, category: 'queue', group: 'limits', type: 'number' },
    { key: 'queue.auto_call', value: false, category: 'queue', group: 'automation', type: 'boolean' },
    { key: 'queue.escalation_timeout', value: 15, category: 'queue', group: 'escalation', type: 'number' },

    // Notification Settings
    { key: 'notification.email_enabled', value: true, category: 'notification', group: 'email', type: 'boolean' },
    { key: 'notification.sms_enabled', value: false, category: 'notification', group: 'sms', type: 'boolean' },

    // Display Settings
    { key: 'display.theme', value: 'light', category: 'appearance', group: 'theme', type: 'string' },
    { key: 'display.primary_color', value: '#667eea', category: 'appearance', group: 'colors', type: 'string' },
    { key: 'display.refresh_interval', value: 5, category: 'appearance', group: 'display', type: 'number' },

    // Business Hours
    { key: 'business.working_days', value: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'], category: 'business', group: 'hours', type: 'array' },
    { key: 'business.start_time', value: '09:00', category: 'business', group: 'hours', type: 'string' },
    { key: 'business.end_time', value: '17:00', category: 'business', group: 'hours', type: 'string' }
];

const initializeSystem = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('Connected to GadaH Database');

        // Clear existing data
        await Privilege.deleteMany();
        await Role.deleteMany();
        await Configuration.deleteMany();
        await Service.deleteMany();
        await Zone.deleteMany();
        await User.deleteMany();

        console.log('Cleared existing data from GadaH Database');

        console.log('Creating privileges...');
        const createdPrivileges = {};
        for (const priv of privileges) {
            const created = await Privilege.create(priv);
            createdPrivileges[priv.code] = created._id;
            console.log(`  ✓ Created privilege: ${priv.name}`);
        }

        console.log('\nCreating roles...');
        const createdRoles = {};
        for (const role of roles) {
            const rolePrivileges = role.privileges.map(code => createdPrivileges[code]).filter(Boolean);
            const created = await Role.create({
                ...role,
                privileges: rolePrivileges
            });
            createdRoles[role.code] = created;
            console.log(`  ✓ Created role: ${role.name}`);
        }

        console.log('\nCreating system configurations...');
        for (const config of configurations) {
            await Configuration.create(config);
            console.log(`  ✓ Created config: ${config.key}`);
        }

        console.log('\nCreating services...');
        const services = await Service.create([
            { name: 'General Service', code: 'GEN', estimatedDuration: 5, color: '#667eea' },
            { name: 'Priority Service', code: 'PRI', estimatedDuration: 3, isPriority: true, color: '#f59e0b' },
            { name: 'Information Desk', code: 'INF', estimatedDuration: 2, color: '#10b981' },
            { name: 'Payment Services', code: 'PAY', estimatedDuration: 7, color: '#ef4444' }
        ]);
        console.log(`  ✓ Created ${services.length} services`);

        console.log('\nCreating zones...');
        const zones = await Zone.create([
            { name: 'Main Hall', code: 'MH', description: 'Main service area for GadaH', settings: { allowPriority: true, maxQueueLength: 50 } },
            { name: 'VIP Lounge', code: 'VIP', description: 'VIP and priority services', settings: { allowPriority: true, maxQueueLength: 20 } },
            { name: 'Express Counter', code: 'EXP', description: 'Express services', settings: { allowPriority: false, maxQueueLength: 30 } }
        ]);
        console.log(`  ✓ Created ${zones.length} zones`);

        console.log('\nCreating admin user...');
        const adminRole = await Role.findOne({ code: 'admin' });
        const adminPassword = await bcrypt.hash('admin123', 12);
        const admin = await User.create({
            name: 'System Administrator',
            email: 'admin@gadah.com',
            password: adminPassword,
            role: adminRole._id,
            status: 'active'
        });
        console.log('  ✓ Admin user created: admin@gadah.com / admin123');

        console.log('\n🎉 GadaH System initialization completed!');
        console.log('\n📝 Default Login Credentials for GadaH:');
        console.log('   Email: admin@gadah.com');
        console.log('   Password: admin123');

        process.exit(0);
    } catch (error) {
        console.error('Error initializing GadaH System:', error);
        process.exit(1);
    }
};

initializeSystem();