<nav className="bg-white shadow-sm">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">GadaH Dashboard</h1>
            <div className="flex items-center space-x-4">
                <span className={`px-3 py-1 rounded-full text-sm ${isConnected ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {isConnected ? '● Live' : '○ Offline'}
                </span>
                <span className="text-gray-600">{user?.name}</span>
            </div>
        </div>
    </div>
</nav>