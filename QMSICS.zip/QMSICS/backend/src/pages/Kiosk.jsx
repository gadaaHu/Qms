<div className="min-h-screen bg-gradient-to-br from-primary-600 to-secondary-600 flex items-center justify-center p-4">
    <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8">
        <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">GadaH Kiosk</h1>
            <p className="text-gray-600 mt-2">Take a ticket for service</p>
        </div>
        {/* Rest of the form... */}
    </div>
</div>