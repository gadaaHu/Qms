const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const dotenv = require('dotenv');
const database = require('./config/database');
const errorHandler = require('./middleware/errorHandler');

// Load environment variables
dotenv.config();

const app = express();
const server = http.createServer(app);

// Socket.IO setup
const io = socketIo(server, {
    cors: {
        origin: process.env.CLIENT_URL ? process.env.CLIENT_URL.split(',') : ['http://localhost:3000', 'http://localhost:5173'],
        credentials: true,
    },
});

// Middleware
app.use(helmet());
app.use(cors({
    origin: process.env.CLIENT_URL ? process.env.CLIENT_URL.split(',') : ['http://localhost:3000', 'http://localhost:5173'],
    credentials: true,
}));
app.use(compression());
app.use(express.json());
app.use(morgan('dev'));

// Make io accessible to routes
app.set('io', io);

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/tickets', require('./routes/tickets'));
app.use('/api/counters', require('./routes/counters'));
app.use('/api/zones', require('./routes/zones'));
app.use('/api/services', require('./routes/services'));
app.use('/api/admin', require('./routes/admin'));

// Health check endpoint
app.get('/health', async (req, res) => {
    const dbStatus = database.getConnectionStatus();
    const dbHealth = await database.healthCheck();

    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: process.env.NODE_ENV,
        database: {
            status: dbStatus,
            health: dbHealth.status,
            message: dbHealth.message,
        },
        services: {
            api: 'running',
            websocket: io.engine !== undefined,
        },
        version: require('../package.json').version,
    });
});

// Socket.IO connection
io.on('connection', (socket) => {
    console.log('🔌 New client connected:', socket.id);
    socket.on('disconnect', () => {
        console.log('🔌 Client disconnected:', socket.id);
    });
});

// Error handler
app.use(errorHandler);

// Start server
const PORT = process.env.PORT || 5000;

const startServer = async () => {
    try {
        await database.connect();

        server.listen(PORT, () => {
            console.log(`
╔══════════════════════════════════════════════════════════════════════╗
║                    QUEUE MANAGEMENT SYSTEM API                       ║
╠══════════════════════════════════════════════════════════════════════╣
║ 🚀 Server:          http://localhost:${PORT}                              ║
║ 🔌 WebSocket:       ws://localhost:${PORT}                                 ║
║ 💾 Database:        ${database.getConnectionStatus().padEnd(46)}║
║ 📡 Environment:     ${(process.env.NODE_ENV || 'development').padEnd(46)}║
║ 🌐 Frontend URL:    ${(process.env.CLIENT_URL || 'http://localhost:3000').padEnd(46)}║
╚══════════════════════════════════════════════════════════════════════╝
      `);
        });
    } catch (error) {
        console.error('❌ Failed to start server:', error);
        process.exit(1);
    }
};

startServer();

module.exports = { app, server, io };
server.listen(PORT, () => {
    console.log(`
╔══════════════════════════════════════════════════════════════════════╗
║                  G A D A H   Q U E U E   S Y S T E M                 ║
╠══════════════════════════════════════════════════════════════════════╣
║ 🚀 Server:          http://localhost:${PORT}                              ║
║ 🔌 WebSocket:       ws://localhost:${PORT}                                 ║
║ 💾 Database:        GadaH - ${database.getConnectionStatus().padEnd(32)}║
║ 📡 Environment:     ${(process.env.NODE_ENV || 'development').padEnd(46)}║
║ 🌐 Frontend URL:    ${(process.env.CLIENT_URL || 'http://localhost:3000').padEnd(46)}║
╚══════════════════════════════════════════════════════════════════════╝
  `);
});