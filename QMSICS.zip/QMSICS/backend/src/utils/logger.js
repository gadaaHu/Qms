const winston = require('winston');
const path = require('path');
const fs = require('fs');
const DailyRotateFile = require('winston-daily-rotate-file');

// Create logs directory if it doesn't exist
const logDir = path.join(__dirname, '../../logs');
if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
}

// Define custom log format with colors
const logFormat = winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.errors({ stack: true }),
    winston.format.splat(),
    winston.format.printf(({ timestamp, level, message, stack, ...meta }) => {
        let log = `${timestamp} [${level.toUpperCase()}]: ${message}`;

        // Add stack trace if available
        if (stack) {
            log += `\n${stack}`;
        }

        // Add meta data if available
        if (Object.keys(meta).length > 0) {
            log += ` ${JSON.stringify(meta)}`;
        }

        return log;
    })
);

// Console format with colors
const consoleFormat = winston.format.combine(
    winston.format.colorize(),
    winston.format.timestamp({ format: 'HH:mm:ss' }),
    winston.format.printf(({ timestamp, level, message, ...meta }) => {
        let log = `${timestamp} [${level}]: ${message}`;
        if (Object.keys(meta).length > 0) {
            log += ` ${JSON.stringify(meta)}`;
        }
        return log;
    })
);

// Daily rotate file transport configuration
const dailyRotateFileTransport = new DailyRotateFile({
    filename: path.join(logDir, 'application-%DATE%.log'),
    datePattern: 'YYYY-MM-DD',
    maxSize: '20m',
    maxFiles: '14d',
    format: logFormat,
    level: 'info'
});

// Error file transport
const errorFileTransport = new winston.transports.File({
    filename: path.join(logDir, 'error.log'),
    level: 'error',
    maxsize: 5242880, // 5MB
    maxFiles: 5,
    format: logFormat
});

// Combined log file transport
const combinedFileTransport = new winston.transports.File({
    filename: path.join(logDir, 'combined.log'),
    maxsize: 5242880, // 5MB
    maxFiles: 5,
    format: logFormat
});

// Console transport for development
const consoleTransport = new winston.transports.Console({
    format: consoleFormat,
    level: process.env.NODE_ENV === 'production' ? 'info' : 'debug'
});

// Create logger instance
const logger = winston.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: logFormat,
    transports: [
        consoleTransport,
        dailyRotateFileTransport,
        errorFileTransport,
        combinedFileTransport
    ],
    exceptionHandlers: [
        new winston.transports.File({
            filename: path.join(logDir, 'exceptions.log'),
            maxsize: 5242880,
            maxFiles: 5,
            format: logFormat
        })
    ],
    rejectionHandlers: [
        new winston.transports.File({
            filename: path.join(logDir, 'rejections.log'),
            maxsize: 5242880,
            maxFiles: 5,
            format: logFormat
        })
    ],
    exitOnError: false
});

// Add Morgan stream for HTTP logging
logger.stream = {
    write: (message) => {
        logger.info(message.trim());
    }
};

// Helper methods for different log levels
logger.debugWithContext = (message, context = {}) => {
    logger.debug(message, { ...context, timestamp: new Date().toISOString() });
};

logger.infoWithContext = (message, context = {}) => {
    logger.info(message, { ...context, timestamp: new Date().toISOString() });
};

logger.warnWithContext = (message, context = {}) => {
    logger.warn(message, { ...context, timestamp: new Date().toISOString() });
};

logger.errorWithContext = (message, error = null, context = {}) => {
    if (error) {
        logger.error(message, {
            ...context,
            error: error.message,
            stack: error.stack,
            timestamp: new Date().toISOString()
        });
    } else {
        logger.error(message, { ...context, timestamp: new Date().toISOString() });
    }
};

// Log request details
logger.logRequest = (req, res, responseTime) => {
    logger.info(`${req.method} ${req.url}`, {
        method: req.method,
        url: req.url,
        statusCode: res.statusCode,
        responseTime: `${responseTime}ms`,
        ip: req.ip,
        userAgent: req.get('user-agent'),
        requestId: req.requestId
    });
};

// Log database operations
logger.logDatabase = (operation, collection, query, duration) => {
    logger.debug(`Database ${operation} on ${collection}`, {
        operation,
        collection,
        query,
        duration: `${duration}ms`,
        timestamp: new Date().toISOString()
    });
};

// Log user actions
logger.logUserAction = (userId, action, details = {}) => {
    logger.info(`User Action: ${action}`, {
        userId,
        action,
        details,
        timestamp: new Date().toISOString()
    });
};

// Log system events
logger.logSystemEvent = (event, details = {}) => {
    logger.info(`System Event: ${event}`, {
        event,
        details,
        timestamp: new Date().toISOString()
    });
};

// Performance logging
logger.logPerformance = (operation, duration, metadata = {}) => {
    logger.info(`Performance: ${operation} took ${duration}ms`, {
        operation,
        duration: `${duration}ms`,
        ...metadata,
        timestamp: new Date().toISOString()
    });
};

// Error logging with context
logger.logError = (error, context = {}) => {
    logger.error(error.message, {
        error: error.message,
        stack: error.stack,
        name: error.name,
        ...context,
        timestamp: new Date().toISOString()
    });
};

// API response logging
logger.logAPIResponse = (req, res, data, error = null) => {
    const logData = {
        method: req.method,
        url: req.url,
        statusCode: res.statusCode,
        requestId: req.requestId,
        ip: req.ip,
        userAgent: req.get('user-agent'),
        responseTime: res.responseTime,
        timestamp: new Date().toISOString()
    };

    if (error) {
        logData.error = error.message;
        logger.error(`API Error: ${req.method} ${req.url}`, logData);
    } else {
        logger.info(`API Response: ${req.method} ${req.url}`, logData);
    }
};

// Memory usage logging
logger.logMemoryUsage = () => {
    const memoryUsage = process.memoryUsage();
    logger.debug('Memory Usage', {
        rss: `${Math.round(memoryUsage.rss / 1024 / 1024)} MB`,
        heapTotal: `${Math.round(memoryUsage.heapTotal / 1024 / 1024)} MB`,
        heapUsed: `${Math.round(memoryUsage.heapUsed / 1024 / 1024)} MB`,
        external: `${Math.round(memoryUsage.external / 1024 / 1024)} MB`,
        timestamp: new Date().toISOString()
    });
};

// Environment logging
logger.logEnvironment = () => {
    logger.info('Environment Configuration', {
        nodeEnv: process.env.NODE_ENV,
        logLevel: process.env.LOG_LEVEL,
        platform: process.platform,
        nodeVersion: process.version,
        pid: process.pid,
        timestamp: new Date().toISOString()
    });
};

// Graceful shutdown logging
logger.logShutdown = (signal) => {
    logger.info(`Received ${signal}, shutting down gracefully...`, {
        signal,
        timestamp: new Date().toISOString(),
        uptime: process.uptime()
    });
};

// Export logger instance
module.exports = logger;