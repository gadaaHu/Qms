const Zone = require('../models/Zone');
const Counter = require('../models/Counter');
const User = require('../models/User');

// @desc    Get all zones
// @route   GET /api/zones
// @access  Private
exports.getZones = async (req, res) => {
    try {
        const zones = await Zone.find()
            .populate('assignedCounters', 'name code status')
            .populate('assignedUsers', 'name email role');

        res.json({ success: true, data: zones });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get zone by ID
// @route   GET /api/zones/:id
// @access  Private
exports.getZone = async (req, res) => {
    try {
        const zone = await Zone.findById(req.params.id)
            .populate('assignedCounters')
            .populate('assignedUsers');

        if (!zone) {
            return res.status(404).json({ success: false, message: 'Zone not found' });
        }

        res.json({ success: true, data: zone });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Create zone
// @route   POST /api/zones
// @access  Private/Admin
exports.createZone = async (req, res) => {
    try {
        const { name, code, description, location, settings } = req.body;

        // Check if zone code exists
        const existingZone = await Zone.findOne({ code });
        if (existingZone) {
            return res.status(400).json({ success: false, message: 'Zone code already exists' });
        }

        const zone = new Zone({
            name,
            code,
            description,
            location,
            settings: settings || {
                allowPriority: true,
                maxQueueLength: 50,
                displaySettings: { screenLayout: 'default', theme: 'light' }
            },
            isActive: true
        });

        await zone.save();
        res.status(201).json({ success: true, data: zone });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Update zone
// @route   PUT /api/zones/:id
// @access  Private/Admin
exports.updateZone = async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;

        const zone = await Zone.findByIdAndUpdate(
            id,
            { ...updates, updatedAt: Date.now() },
            { new: true, runValidators: true }
        );

        if (!zone) {
            return res.status(404).json({ success: false, message: 'Zone not found' });
        }

        res.json({ success: true, data: zone });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Delete zone
// @route   DELETE /api/zones/:id
// @access  Private/Admin
exports.deleteZone = async (req, res) => {
    try {
        const { id } = req.params;

        // Check if zone has counters
        const counters = await Counter.countDocuments({ zone: id });
        if (counters > 0) {
            return res.status(400).json({
                success: false,
                message: `Cannot delete zone with ${counters} assigned counters`
            });
        }

        const zone = await Zone.findByIdAndDelete(id);
        if (!zone) {
            return res.status(404).json({ success: false, message: 'Zone not found' });
        }

        res.json({ success: true, message: 'Zone deleted successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Assign counters to zone
// @route   POST /api/zones/:id/assign-counters
// @access  Private/Admin
exports.assignCounters = async (req, res) => {
    try {
        const { id } = req.params;
        const { counterIds } = req.body;

        const zone = await Zone.findById(id);
        if (!zone) {
            return res.status(404).json({ success: false, message: 'Zone not found' });
        }

        // Update counters with zone assignment
        await Counter.updateMany(
            { _id: { $in: counterIds } },
            { zone: id }
        );

        zone.assignedCounters = counterIds;
        await zone.save();

        res.json({ success: true, data: zone });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get zone statistics
// @route   GET /api/zones/:id/stats
// @access  Private
exports.getZoneStats = async (req, res) => {
    try {
        const { id } = req.params;

        const zone = await Zone.findById(id);
        if (!zone) {
            return res.status(404).json({ success: false, message: 'Zone not found' });
        }

        const counters = await Counter.find({ zone: id });
        const activeCounters = counters.filter(c => c.status === 'active').length;
        const totalServed = counters.reduce((sum, c) => sum + (c.totalServed || 0), 0);

        res.json({
            success: true,
            data: {
                zone: { id: zone._id, name: zone.name, code: zone.code },
                totalCounters: counters.length,
                activeCounters,
                totalServed,
                averageServiceTime: counters.reduce((sum, c) => sum + (c.averageServiceTime || 0), 0) / counters.length || 0
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Toggle zone status
// @route   PATCH /api/zones/:id/toggle-status
// @access  Private/Admin
exports.toggleZoneStatus = async (req, res) => {
    try {
        const { id } = req.params;

        const zone = await Zone.findById(id);
        if (!zone) {
            return res.status(404).json({ success: false, message: 'Zone not found' });
        }

        zone.isActive = !zone.isActive;
        await zone.save();

        res.json({
            success: true,
            data: { id: zone._id, isActive: zone.isActive },
            message: `Zone ${zone.isActive ? 'activated' : 'deactivated'}`
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};