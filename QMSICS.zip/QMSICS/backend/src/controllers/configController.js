const Configuration = require('../models/Configuration');
const AuditLog = require('../models/AuditLog');

// @desc    Get system configuration
// @route   GET /api/admin/config
// @access  Private/Admin
exports.getConfig = async (req, res) => {
    try {
        const configs = await Configuration.find()
            .populate('updatedBy', 'name email')
            .sort({ category: 1, group: 1 });

        // Format as key-value pairs
        const configMap = {};
        configs.forEach(config => {
            configMap[config.key] = config.value;
        });

        res.json({
            success: true,
            data: configs,
            configMap
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Update system configuration
// @route   PUT /api/admin/config/:key
// @access  Private/Admin
exports.updateConfig = async (req, res) => {
    try {
        const { key } = req.params;
        const { value } = req.body;

        const config = await Configuration.findOneAndUpdate(
            { key },
            {
                value,
                updatedBy: req.user._id,
                updatedAt: Date.now()
            },
            { upsert: true, new: true }
        );

        // Log audit
        await AuditLog.create({
            user: req.user._id,
            action: 'UPDATE_CONFIG',
            entity: 'Configuration',
            entityId: config._id,
            details: { key, value }
        });

        res.json({
            success: true,
            data: config,
            message: 'Configuration updated successfully'
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Bulk update configurations
// @route   POST /api/admin/config/bulk
// @access  Private/Admin
exports.bulkUpdateConfig = async (req, res) => {
    try {
        const { updates } = req.body;
        const results = [];

        for (const update of updates) {
            const config = await Configuration.findOneAndUpdate(
                { key: update.key },
                {
                    value: update.value,
                    updatedBy: req.user._id,
                    updatedAt: Date.now()
                },
                { upsert: true, new: true }
            );
            results.push({ key: update.key, success: true, config });
        }

        res.json({
            success: true,
            data: results,
            message: `${results.length} configurations updated`
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get system settings groups
// @route   GET /api/admin/config/groups
// @access  Private/Admin
exports.getConfigGroups = async (req, res) => {
    try {
        const groups = await Configuration.aggregate([
            {
                $group: {
                    _id: { category: '$category', group: '$group' },
                    count: { $sum: 1 },
                    configs: { $push: '$$ROOT' }
                }
            },
            { $sort: { '_id.category': 1, '_id.group': 1 } }
        ]);

        res.json({ success: true, data: groups });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};