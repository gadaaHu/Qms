const Ticket = require('../models/Ticket');
const Counter = require('../models/Counter');
const User = require('../models/User');
const { escalateTicket, reorderQueue } = require('../services/queueService');
const { emitTicketUpdate } = require('../utils/socket');

// @desc    Get live dashboard data
// @route   GET /api/supervisor/dashboard
// @access  Private/Supervisor
exports.getLiveDashboard = async (req, res) => {
    try {
        // Get queue statistics
        const waiting = await Ticket.countDocuments({ status: 'waiting' });
        const called = await Ticket.countDocuments({ status: 'called' });
        const inService = await Ticket.countDocuments({ status: 'in_service' });

        // Get today's completed tickets
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const completedToday = await Ticket.countDocuments({
            status: 'completed',
            completedAt: { $gte: today }
        });

        // Get average wait time
        const avgWaitTime = await Ticket.aggregate([
            { $match: { actualWaitTime: { $exists: true, $ne: null } } },
            { $group: { _id: null, avg: { $avg: '$actualWaitTime' } } }
        ]);

        // Get active counters
        const activeCounters = await Counter.find({ status: 'active' })
            .populate('operator', 'name')
            .populate('servingTicket');

        // Get escalated tickets
        const escalatedTickets = await Ticket.find({ isEscalated: true, status: { $ne: 'completed' } })
            .populate('service', 'name')
            .populate('counter', 'name')
            .sort({ createdAt: -1 });

        // Get service-wise queue
        const serviceQueue = await Ticket.aggregate([
            { $match: { status: 'waiting' } },
            { $group: { _id: '$service', count: { $sum: 1 } } },
            { $lookup: { from: 'services', localField: '_id', foreignField: '_id', as: 'service' } },
            { $unwind: '$service' }
        ]);

        res.json({
            success: true,
            data: {
                queue: {
                    waiting,
                    called,
                    inService,
                    completedToday
                },
                averageWaitTime: avgWaitTime[0]?.avg || 0,
                activeCounters,
                escalatedTickets,
                serviceQueue
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Escalate ticket
// @route   POST /api/supervisor/escalate
// @access  Private/Supervisor
exports.escalateTicket = async (req, res) => {
    try {
        const { ticketId, reason } = req.body;

        const ticket = await escalateTicket(ticketId, reason);
        if (!ticket) {
            return res.status(404).json({
                success: false,
                message: 'Ticket not found'
            });
        }

        // Emit real-time event
        emitTicketUpdate('ticket_escalated', ticket);

        // Log audit
        await AuditLog.create({
            user: req.user._id,
            action: 'ESCALATE_TICKET',
            entity: 'Ticket',
            entityId: ticketId,
            details: { reason, ticketNumber: ticket.number }
        });

        res.json({
            success: true,
            data: ticket,
            message: `Ticket ${ticket.number} escalated successfully`
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Reorder queue
// @route   POST /api/supervisor/reorder
// @access  Private/Supervisor
exports.reorderQueue = async (req, res) => {
    try {
        const { ticketIds } = req.body;

        await reorderQueue(ticketIds);

        // Emit real-time event
        emitTicketUpdate('queue_reordered', { ticketIds });

        // Log audit
        await AuditLog.create({
            user: req.user._id,
            action: 'REORDER_QUEUE',
            entity: 'Queue',
            details: { ticketIds }
        });

        res.json({
            success: true,
            message: 'Queue reordered successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Get all counters status
// @route   GET /api/supervisor/counters
// @access  Private/Supervisor
exports.getCountersStatus = async (req, res) => {
    try {
        const counters = await Counter.find()
            .populate('operator', 'name email')
            .populate('servingTicket')
            .populate('zone', 'name code')
            .sort({ name: 1 });

        const stats = counters.map(counter => ({
            id: counter._id,
            name: counter.name,
            code: counter.code,
            zone: counter.zone,
            operator: counter.operator,
            status: counter.status,
            servingTicket: counter.servingTicket,
            totalServed: counter.totalServed,
            averageServiceTime: counter.averageServiceTime,
            lastCalledAt: counter.lastCalledAt
        }));

        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Get performance metrics
// @route   GET /api/supervisor/performance
// @access  Private/Supervisor
exports.getPerformanceMetrics = async (req, res) => {
    try {
        const { period = 'day' } = req.query;

        let startDate;
        const now = new Date();

        switch (period) {
            case 'day':
                startDate = new Date(now.setHours(0, 0, 0, 0));
                break;
            case 'week':
                startDate = new Date(now.setDate(now.getDate() - 7));
                break;
            case 'month':
                startDate = new Date(now.setMonth(now.getMonth() - 1));
                break;
            default:
                startDate = new Date(now.setHours(0, 0, 0, 0));
        }

        const tickets = await Ticket.find({
            completedAt: { $gte: startDate }
        });

        const totalTickets = tickets.length;
        const avgWaitTime = tickets.reduce((sum, t) => sum + (t.actualWaitTime || 0), 0) / totalTickets || 0;
        const avgServiceTime = tickets.reduce((sum, t) => sum + (t.serviceTime || 0), 0) / totalTickets || 0;

        // Operator performance
        const operatorPerformance = await Ticket.aggregate([
            { $match: { operator: { $exists: true }, status: 'completed' } },
            {
                $group: {
                    _id: '$operator',
                    total: { $sum: 1 },
                    avgServiceTime: { $avg: '$serviceTime' }
                }
            },
            { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'operator' } },
            { $unwind: '$operator' }
        ]);

        res.json({
            success: true,
            data: {
                period,
                totalTickets,
                avgWaitTime,
                avgServiceTime,
                operatorPerformance
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Get SLA compliance
// @route   GET /api/supervisor/sla
// @access  Private/Supervisor
exports.getSLACompliance = async (req, res) => {
    try {
        const services = await Service.find();
        const slaData = [];

        for (const service of services) {
            const completedTickets = await Ticket.find({
                service: service._id,
                status: 'completed'
            });

            const withinSLA = completedTickets.filter(t =>
                (t.serviceTime || 0) <= service.slaTime
            ).length;

            slaData.push({
                service: service.name,
                slaTime: service.slaTime,
                total: completedTickets.length,
                withinSLA,
                compliance: completedTickets.length > 0
                    ? (withinSLA / completedTickets.length) * 100
                    : 100
            });
        }

        res.json({
            success: true,
            data: slaData
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};