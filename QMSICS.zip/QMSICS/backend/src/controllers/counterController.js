const Counter = require('../models/Counter');
const Ticket = require('../models/Ticket');
const User = require('../models/User');
const { callNextTicket } = require('../services/queueService');
const { emitTicketUpdate } = require('../utils/socket');

// @desc    Get all counters
// @route   GET /api/counters
// @access  Private
exports.getCounters = async (req, res) => {
    try {
        const { zone, status } = req.query;
        let filter = {};

        if (zone) filter.zone = zone;
        if (status) filter.status = status;

        const counters = await Counter.find(filter)
            .populate('zone', 'name code')
            .populate('operator', 'name email')
            .populate('services', 'name code color')
            .sort({ name: 1 });

        res.json({
            success: true,
            data: counters
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Get single counter
// @route   GET /api/counters/:id
// @access  Private
exports.getCounter = async (req, res) => {
    try {
        const counter = await Counter.findById(req.params.id)
            .populate('zone', 'name code')
            .populate('operator', 'name email')
            .populate('services', 'name code color')
            .populate('currentTicket')
            .populate('servingTicket');

        if (!counter) {
            return res.status(404).json({
                success: false,
                message: 'Counter not found'
            });
        }

        res.json({
            success: true,
            data: counter
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Create counter
// @route   POST /api/counters
// @access  Private/Admin
exports.createCounter = async (req, res) => {
    try {
        const { name, code, zone, services } = req.body;

        // Check if counter code exists
        const existingCounter = await Counter.findOne({ code });
        if (existingCounter) {
            return res.status(400).json({
                success: false,
                message: 'Counter code already exists'
            });
        }

        const counter = new Counter({
            name,
            code,
            zone,
            services,
            status: 'active'
        });

        await counter.save();

        res.status(201).json({
            success: true,
            data: counter,
            message: 'Counter created successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Update counter
// @route   PUT /api/counters/:id
// @access  Private/Admin
exports.updateCounter = async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;

        const counter = await Counter.findByIdAndUpdate(
            id,
            { ...updates, updatedAt: Date.now() },
            { new: true, runValidators: true }
        );

        if (!counter) {
            return res.status(404).json({
                success: false,
                message: 'Counter not found'
            });
        }

        res.json({
            success: true,
            data: counter,
            message: 'Counter updated successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Delete counter
// @route   DELETE /api/counters/:id
// @access  Private/Admin
exports.deleteCounter = async (req, res) => {
    try {
        const { id } = req.params;

        const counter = await Counter.findByIdAndDelete(id);
        if (!counter) {
            return res.status(404).json({
                success: false,
                message: 'Counter not found'
            });
        }

        res.json({
            success: true,
            message: 'Counter deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Call next ticket
// @route   POST /api/counters/:id/call
// @access  Private/Operator
exports.callNext = async (req, res) => {
    try {
        const { id } = req.params;

        const counter = await Counter.findById(id);
        if (!counter) {
            return res.status(404).json({
                success: false,
                message: 'Counter not found'
            });
        }

        // Check if counter is active
        if (counter.status !== 'active') {
            return res.status(400).json({
                success: false,
                message: 'Counter is not active'
            });
        }

        // Check if counter already serving
        if (counter.servingTicket) {
            return res.status(400).json({
                success: false,
                message: 'Counter is already serving a ticket'
            });
        }

        // Call next ticket
        const nextTicket = await callNextTicket(counter);

        if (!nextTicket) {
            return res.status(404).json({
                success: false,
                message: 'No waiting tickets for this counter'
            });
        }

        // Update counter
        counter.currentTicket = nextTicket._id;
        counter.servingTicket = nextTicket._id;
        counter.lastCalledAt = new Date();
        await counter.save();

        // Emit real-time event
        emitTicketUpdate('ticket_called', {
            counter: counter._id,
            ticket: nextTicket,
            counterName: counter.name
        });

        res.json({
            success: true,
            data: nextTicket,
            message: `Ticket ${nextTicket.number} called`
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Complete service
// @route   POST /api/counters/:id/complete/:ticketId
// @access  Private/Operator
exports.completeService = async (req, res) => {
    try {
        const { id, ticketId } = req.params;

        const counter = await Counter.findById(id);
        if (!counter) {
            return res.status(404).json({
                success: false,
                message: 'Counter not found'
            });
        }

        const ticket = await Ticket.findById(ticketId);
        if (!ticket) {
            return res.status(404).json({
                success: false,
                message: 'Ticket not found'
            });
        }

        // Update ticket
        ticket.status = 'completed';
        ticket.completedAt = new Date();
        ticket.serviceTime = (ticket.completedAt - ticket.startedAt) / 1000 / 60;
        ticket.actualWaitTime = (ticket.startedAt - ticket.issuedAt) / 1000 / 60;
        await ticket.save();

        // Update counter stats
        counter.totalServed += 1;
        counter.servingTicket = null;
        counter.currentTicket = null;

        // Update average service time
        if (counter.totalServed > 0) {
            counter.averageServiceTime =
                (counter.averageServiceTime * (counter.totalServed - 1) + ticket.serviceTime) / counter.totalServed;
        }
        await counter.save();

        // Emit real-time event
        emitTicketUpdate('ticket_completed', ticket);

        res.json({
            success: true,
            data: ticket,
            message: `Service completed for ticket ${ticket.number}`
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Start break
// @route   POST /api/counters/:id/break
// @access  Private/Operator
exports.startBreak = async (req, res) => {
    try {
        const { id } = req.params;

        const counter = await Counter.findById(id);
        if (!counter) {
            return res.status(404).json({
                success: false,
                message: 'Counter not found'
            });
        }

        // Check if serving ticket
        if (counter.servingTicket) {
            return res.status(400).json({
                success: false,
                message: 'Cannot start break while serving a ticket'
            });
        }

        counter.status = 'break';
        await counter.save();

        res.json({
            success: true,
            data: counter,
            message: 'Counter on break'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    End break
// @route   POST /api/counters/:id/resume
// @access  Private/Operator
exports.endBreak = async (req, res) => {
    try {
        const { id } = req.params;

        const counter = await Counter.findById(id);
        if (!counter) {
            return res.status(404).json({
                success: false,
                message: 'Counter not found'
            });
        }

        counter.status = 'active';
        await counter.save();

        res.json({
            success: true,
            data: counter,
            message: 'Counter resumed'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Get counter stats
// @route   GET /api/counters/stats
// @access  Private
exports.getCounterStats = async (req, res) => {
    try {
        const counters = await Counter.find()
            .populate('operator', 'name');

        const stats = counters.map(counter => ({
            id: counter._id,
            name: counter.name,
            code: counter.code,
            operator: counter.operator,
            status: counter.status,
            totalServed: counter.totalServed,
            averageServiceTime: counter.averageServiceTime,
            lastCalledAt: counter.lastCalledAt
        }));

        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};