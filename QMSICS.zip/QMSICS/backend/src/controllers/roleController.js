const Role = require('../models/Role');
const Privilege = require('../models/Privilege');
const User = require('../models/User');

// @desc    Get all roles
// @route   GET /api/admin/roles
// @access  Private/Admin
exports.getRoles = async (req, res) => {
    try {
        const roles = await Role.find().populate('privileges');
        res.json({ success: true, data: roles });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get single role
// @route   GET /api/admin/roles/:id
// @access  Private/Admin
exports.getRole = async (req, res) => {
    try {
        const role = await Role.findById(req.params.id).populate('privileges');
        if (!role) {
            return res.status(404).json({ success: false, message: 'Role not found' });
        }
        res.json({ success: true, data: role });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Create role
// @route   POST /api/admin/roles
// @access  Private/Admin
exports.createRole = async (req, res) => {
    try {
        const { name, code, description, privileges, level } = req.body;

        // Check if role exists
        const existingRole = await Role.findOne({ $or: [{ name }, { code }] });
        if (existingRole) {
            return res.status(400).json({ success: false, message: 'Role name or code already exists' });
        }

        const role = new Role({
            name,
            code,
            description,
            privileges,
            level: level || 0,
            isSystem: false
        });

        await role.save();
        await role.populate('privileges');

        res.status(201).json({ success: true, data: role });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Update role
// @route   PUT /api/admin/roles/:id
// @access  Private/Admin
exports.updateRole = async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;

        const role = await Role.findById(id);
        if (!role) {
            return res.status(404).json({ success: false, message: 'Role not found' });
        }

        // Don't allow editing system roles
        if (role.isSystem && updates.isSystem === false) {
            return res.status(403).json({ success: false, message: 'Cannot modify system roles' });
        }

        Object.assign(role, updates);
        role.updatedAt = Date.now();
        await role.save();
        await role.populate('privileges');

        res.json({ success: true, data: role });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Delete role
// @route   DELETE /api/admin/roles/:id
// @access  Private/Admin
exports.deleteRole = async (req, res) => {
    try {
        const { id } = req.params;

        const role = await Role.findById(id);
        if (!role) {
            return res.status(404).json({ success: false, message: 'Role not found' });
        }

        // Don't allow deleting system roles
        if (role.isSystem) {
            return res.status(403).json({ success: false, message: 'Cannot delete system roles' });
        }

        // Check if any users have this role
        const usersWithRole = await User.countDocuments({ role: id });
        if (usersWithRole > 0) {
            return res.status(400).json({
                success: false,
                message: `Cannot delete role with ${usersWithRole} assigned users`
            });
        }

        await role.deleteOne();
        res.json({ success: true, message: 'Role deleted successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get all privileges
// @route   GET /api/admin/privileges
// @access  Private/Admin
exports.getPrivileges = async (req, res) => {
    try {
        const { module, category } = req.query;
        let filter = {};

        if (module) filter.module = module;
        if (category) filter.category = category;

        const privileges = await Privilege.find(filter).sort({ module: 1, category: 1 });
        res.json({ success: true, data: privileges });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Create privilege
// @route   POST /api/admin/privileges
// @access  Private/Admin
exports.createPrivilege = async (req, res) => {
    try {
        const privilege = new Privilege(req.body);
        await privilege.save();
        res.status(201).json({ success: true, data: privilege });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Update privilege
// @route   PUT /api/admin/privileges/:id
// @access  Private/Admin
exports.updatePrivilege = async (req, res) => {
    try {
        const privilege = await Privilege.findByIdAndUpdate(
            req.params.id,
            { ...req.body, updatedAt: Date.now() },
            { new: true }
        );
        if (!privilege) {
            return res.status(404).json({ success: false, message: 'Privilege not found' });
        }
        res.json({ success: true, data: privilege });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Delete privilege
// @route   DELETE /api/admin/privileges/:id
// @access  Private/Admin
exports.deletePrivilege = async (req, res) => {
    try {
        const privilege = await Privilege.findByIdAndDelete(req.params.id);
        if (!privilege) {
            return res.status(404).json({ success: false, message: 'Privilege not found' });
        }
        res.json({ success: true, message: 'Privilege deleted successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get privileges by module
// @route   GET /api/admin/privileges/modules
// @access  Private/Admin
exports.getPrivilegeModules = async (req, res) => {
    try {
        const modules = await Privilege.aggregate([
            {
                $group: {
                    _id: '$module',
                    privileges: { $push: '$$ROOT' },
                    count: { $sum: 1 }
                }
            },
            { $sort: { _id: 1 } }
        ]);
        res.json({ success: true, data: modules });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};