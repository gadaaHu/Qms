const Performance = require('../models/Performance');
const Ticket = require('../models/Ticket');
const Counter = require('../models/Counter');
const Service = require('../models/Service');

// @desc    Get performance metrics
// @route   GET /api/performance
// @access  Private/Supervisor
exports.getMetrics = async (req, res) => {
    try {
        const { startDate, endDate, interval = 'day' } = req.query;

        let filter = {};
        if (startDate) filter.date = { $gte: new Date(startDate) };
        if (endDate) filter.date = { ...filter.date, $lte: new Date(endDate) };

        const metrics = await Performance.find(filter)
            .sort({ date: -1 });

        // If no aggregated data, calculate on the fly
        if (metrics.length === 0 && startDate && endDate) {
            const tickets = await Ticket.find({
                completedAt: { $gte: new Date(startDate), $lte: new Date(endDate) }
            });

            const dailyMetrics = {};
            tickets.forEach(ticket => {
                const date = ticket.completedAt.toISOString().split('T')[0];
                if (!dailyMetrics[date]) {
                    dailyMetrics[date] = {
                        date,
                        totalTickets: 0,
                        totalWaitTime: 0,
                        totalServiceTime: 0
                    };
                }
                dailyMetrics[date].totalTickets++;
                dailyMetrics[date].totalWaitTime += ticket.actualWaitTime || 0;
                dailyMetrics[date].totalServiceTime += ticket.serviceTime || 0;
            });

            const calculatedMetrics = Object.values(dailyMetrics).map(day => ({
                date: day.date,
                totalTickets: day.totalTickets,
                avgWaitTime: day.totalTickets > 0 ? day.totalWaitTime / day.totalTickets : 0,
                avgServiceTime: day.totalTickets > 0 ? day.totalServiceTime / day.totalTickets : 0
            }));

            return res.json({
                success: true,
                data: calculatedMetrics
            });
        }

        res.json({
            success: true,
            data: metrics
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Generate report
// @route   POST /api/performance/report
// @access  Private/Supervisor
exports.generateReport = async (req, res) => {
    try {
        const { date = new Date() } = req.body;
        const startOfDay = new Date(date);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(date);
        endOfDay.setHours(23, 59, 59, 999);

        // Get tickets for the day
        const tickets = await Ticket.find({
            completedAt: { $gte: startOfDay, $lte: endOfDay }
        }).populate('service', 'name')
            .populate('counter', 'name')
            .populate('operator', 'name');

        const total = tickets.length;
        const avgWait = tickets.reduce((sum, t) => sum + (t.actualWaitTime || 0), 0) / total || 0;
        const avgService = tickets.reduce((sum, t) => sum + (t.serviceTime || 0), 0) / total || 0;

        // Service breakdown
        const serviceBreakdown = {};
        tickets.forEach(ticket => {
            const serviceName = ticket.service?.name || 'Unknown';
            serviceBreakdown[serviceName] = (serviceBreakdown[serviceName] || 0) + 1;
        });

        // Counter performance
        const counterPerformance = {};
        tickets.forEach(ticket => {
            const counterName = ticket.counter?.name || 'Unknown';
            if (!counterPerformance[counterName]) {
                counterPerformance[counterName] = {
                    total: 0,
                    totalServiceTime: 0
                };
            }
            counterPerformance[counterName].total++;
            counterPerformance[counterName].totalServiceTime += ticket.serviceTime || 0;
        });

        // Operator performance
        const operatorPerformance = {};
        tickets.forEach(ticket => {
            const operatorName = ticket.operator?.name || 'Unknown';
            if (!operatorPerformance[operatorName]) {
                operatorPerformance[operatorName] = {
                    total: 0,
                    totalServiceTime: 0
                };
            }
            operatorPerformance[operatorName].total++;
            operatorPerformance[operatorName].totalServiceTime += ticket.serviceTime || 0;
        });

        // SLA compliance
        const slaCompliance = tickets.filter(t =>
            (t.serviceTime || 0) <= (t.service?.slaTime || 15)
        ).length;

        const report = {
            date: startOfDay,
            totalTickets: total,
            avgWaitTime: avgWait,
            avgServiceTime: avgService,
            serviceBreakdown,
            counterPerformance,
            operatorPerformance,
            slaCompliance: (slaCompliance / total) * 100 || 100,
            tickets: tickets.map(t => ({
                number: t.number,
                service: t.service?.name,
                counter: t.counter?.name,
                operator: t.operator?.name,
                waitTime: t.actualWaitTime,
                serviceTime: t.serviceTime,
                rating: t.rating
            }))
        };

        // Save to database
        const performance = new Performance({
            date: startOfDay,
            totalTickets: total,
            avgWaitTime: avgWait,
            avgServiceTime: avgService,
            ticketsByService: serviceBreakdown,
            ticketsByCounter: counterPerformance,
            operatorPerformance,
            slaCompliance: (slaCompliance / total) * 100 || 100
        });
        await performance.save();

        res.json({
            success: true,
            data: report,
            message: 'Report generated successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Export report
// @route   GET /api/performance/export
// @access  Private/Supervisor
exports.exportReport = async (req, res) => {
    try {
        const { startDate, endDate, format = 'json' } = req.query;

        const tickets = await Ticket.find({
            completedAt: {
                $gte: new Date(startDate),
                $lte: new Date(endDate)
            }
        }).populate('service', 'name')
            .populate('counter', 'name')
            .populate('operator', 'name');

        const reportData = tickets.map(t => ({
            'Ticket Number': t.number,
            'Service': t.service?.name,
            'Counter': t.counter?.name,
            'Operator': t.operator?.name,
            'Issued At': t.issuedAt,
            'Started At': t.startedAt,
            'Completed At': t.completedAt,
            'Wait Time (min)': t.actualWaitTime,
            'Service Time (min)': t.serviceTime,
            'Rating': t.rating
        }));

        if (format === 'csv') {
            const csv = reportData.map(row =>
                Object.values(row).join(',')
            ).join('\n');

            const header = Object.keys(reportData[0] || {}).join(',');
            const csvContent = `${header}\n${csv}`;

            res.setHeader('Content-Type', 'text/csv');
            res.setHeader('Content-Disposition', 'attachment; filename=report.csv');
            return res.send(csvContent);
        }

        res.json({
            success: true,
            data: reportData
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Get peak hours
// @route   GET /api/performance/peak-hours
// @access  Private/Supervisor
exports.getPeakHours = async (req, res) => {
    try {
        const { days = 30 } = req.query;
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);

        const tickets = await Ticket.find({
            issuedAt: { $gte: startDate }
        });

        const hourDistribution = Array(24).fill(0);
        tickets.forEach(ticket => {
            const hour = new Date(ticket.issuedAt).getHours();
            hourDistribution[hour]++;
        });

        const peakHours = hourDistribution
            .map((count, hour) => ({ hour, count }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 3);

        res.json({
            success: true,
            data: {
                distribution: hourDistribution,
                peakHours
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};