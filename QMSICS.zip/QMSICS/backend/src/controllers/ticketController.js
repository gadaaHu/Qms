const Ticket = require('../models/Ticket');
const Service = require('../models/Service');
const Counter = require('../models/Counter');

// Generate ticket number
const generateTicketNumber = async (serviceCode) => {
    const lastTicket = await Ticket.findOne({ number: new RegExp(`^${serviceCode}`) })
        .sort({ number: -1 });

    let num = 1;
    if (lastTicket) {
        const match = lastTicket.number.match(/\d+/);
        if (match) num = parseInt(match[0]) + 1;
    }
    return `${serviceCode}${num.toString().padStart(3, '0')}`;
};

// Calculate estimated wait time
const calculateWaitTime = async (serviceId) => {
    const waitingCount = await Ticket.countDocuments({
        service: serviceId,
        status: 'waiting'
    });
    const service = await Service.findById(serviceId);
    if (!service) return 5;
    return waitingCount * service.estimatedDuration;
};

exports.createTicket = async (req, res) => {
    try {
        const { serviceId, customerName, customerPhone, customerEmail, priority } = req.body;

        const service = await Service.findById(serviceId);
        if (!service) {
            return res.status(404).json({ success: false, message: 'Service not found' });
        }

        const number = await generateTicketNumber(service.code);
        const estimatedWaitTime = await calculateWaitTime(serviceId);

        const ticket = new Ticket({
            number,
            service: serviceId,
            customerName: customerName || 'Walk-in Customer',
            customerPhone,
            customerEmail,
            priority: priority || 'normal',
            estimatedWaitTime,
            status: 'waiting'
        });

        await ticket.save();
        await ticket.populate('service', 'name code color');

        // Emit real-time update
        const io = req.app.get('io');
        io.emit('new_ticket', ticket);

        res.status(201).json({ success: true, data: ticket });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

exports.getQueueStatus = async (req, res) => {
    try {
        const waiting = await Ticket.find({ status: 'waiting' })
            .populate('service', 'name code color')
            .sort({ priority: -1, issuedAt: 1 });

        const inService = await Ticket.find({ status: 'in_service' })
            .populate('service', 'name')
            .populate('counter', 'name code');

        const called = await Ticket.find({ status: 'called' })
            .populate('service', 'name')
            .populate('counter', 'name code');

        res.json({
            success: true,
            data: {
                waiting: { count: waiting.length, tickets: waiting },
                inService: { count: inService.length, tickets: inService },
                called: { count: called.length, tickets: called }
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

exports.getTickets = async (req, res) => {
    try {
        const tickets = await Ticket.find()
            .populate('service', 'name code color')
            .populate('counter', 'name code')
            .sort({ createdAt: -1 })
            .limit(50);
        res.json({ success: true, data: tickets });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

exports.getTicketById = async (req, res) => {
    try {
        const ticket = await Ticket.findById(req.params.id)
            .populate('service', 'name code color')
            .populate('counter', 'name code')
            .populate('operator', 'name');

        if (!ticket) {
            return res.status(404).json({ success: false, message: 'Ticket not found' });
        }

        res.json({ success: true, data: ticket });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

exports.updateTicketStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, counterId, operatorId } = req.body;

        const ticket = await Ticket.findById(id);
        if (!ticket) {
            return res.status(404).json({ success: false, message: 'Ticket not found' });
        }

        ticket.status = status;

        if (status === 'called') {
            ticket.calledAt = new Date();
            ticket.counter = counterId;
            ticket.operator = operatorId;
        } else if (status === 'in_service') {
            ticket.startedAt = new Date();
            ticket.counter = counterId;
            ticket.operator = operatorId;

            await Counter.findByIdAndUpdate(counterId, {
                servingTicket: id,
                currentTicket: id
            });
        } else if (status === 'completed') {
            ticket.completedAt = new Date();
            ticket.serviceTime = (ticket.completedAt - ticket.startedAt) / 1000 / 60;
            ticket.actualWaitTime = (ticket.startedAt - ticket.issuedAt) / 1000 / 60;

            await Counter.findByIdAndUpdate(ticket.counter, {
                $inc: { totalServed: 1 },
                servingTicket: null,
                currentTicket: null
            });
        }

        await ticket.save();

        const io = req.app.get('io');
        io.emit('ticket_updated', ticket);

        res.json({ success: true, data: ticket });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

exports.rateTicket = async (req, res) => {
    try {
        const { id } = req.params;
        const { rating, feedback } = req.body;

        const ticket = await Ticket.findByIdAndUpdate(
            id,
            { rating, feedback },
            { new: true }
        );

        res.json({ success: true, data: ticket });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};