const Kiosk = require('../models/Kiosk');

// @desc    Get all kiosks
// @route   GET /api/kiosks
// @access  Private
exports.getKiosks = async (req, res) => {
    try {
        const { zone, status } = req.query;
        let filter = {};

        if (zone) filter.zone = zone;
        if (status) filter.status = status;

        const kiosks = await Kiosk.find(filter)
            .populate('zone', 'name code')
            .sort({ name: 1 });

        res.json({
            success: true,
            data: kiosks
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Get single kiosk
// @route   GET /api/kiosks/:id
// @access  Private
exports.getKiosk = async (req, res) => {
    try {
        const kiosk = await Kiosk.findById(req.params.id)
            .populate('zone', 'name code');

        if (!kiosk) {
            return res.status(404).json({
                success: false,
                message: 'Kiosk not found'
            });
        }

        res.json({
            success: true,
            data: kiosk
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Create kiosk
// @route   POST /api/kiosks
// @access  Private/Admin
exports.createKiosk = async (req, res) => {
    try {
        const { name, code, zone, config } = req.body;

        // Check if kiosk code exists
        const existingKiosk = await Kiosk.findOne({ code });
        if (existingKiosk) {
            return res.status(400).json({
                success: false,
                message: 'Kiosk code already exists'
            });
        }

        const kiosk = new Kiosk({
            name,
            code,
            zone,
            config: config || {
                theme: 'default',
                language: 'en',
                printTicket: true,
                showQueueStatus: true
            },
            status: 'online'
        });

        await kiosk.save();

        res.status(201).json({
            success: true,
            data: kiosk,
            message: 'Kiosk created successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Update kiosk
// @route   PUT /api/kiosks/:id
// @access  Private/Admin
exports.updateKiosk = async (req, res) => {
    try {
        const { id } = req.params;

        const kiosk = await Kiosk.findByIdAndUpdate(
            id,
            { ...req.body, updatedAt: Date.now() },
            { new: true, runValidators: true }
        );

        if (!kiosk) {
            return res.status(404).json({
                success: false,
                message: 'Kiosk not found'
            });
        }

        res.json({
            success: true,
            data: kiosk,
            message: 'Kiosk updated successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Delete kiosk
// @route   DELETE /api/kiosks/:id
// @access  Private/Admin
exports.deleteKiosk = async (req, res) => {
    try {
        const { id } = req.params;

        const kiosk = await Kiosk.findByIdAndDelete(id);
        if (!kiosk) {
            return res.status(404).json({
                success: false,
                message: 'Kiosk not found'
            });
        }

        res.json({
            success: true,
            message: 'Kiosk deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Kiosk heartbeat
// @route   POST /api/kiosks/:id/heartbeat
// @access  Public
exports.heartbeat = async (req, res) => {
    try {
        const { id } = req.params;

        const kiosk = await Kiosk.findByIdAndUpdate(
            id,
            {
                lastHeartbeat: new Date(),
                status: 'online',
                ipAddress: req.ip || req.connection.remoteAddress
            },
            { new: true }
        );

        if (!kiosk) {
            return res.status(404).json({
                success: false,
                message: 'Kiosk not found'
            });
        }

        res.json({
            success: true,
            message: 'Heartbeat received',
            timestamp: new Date()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Update kiosk configuration
// @route   PATCH /api/kiosks/:id/config
// @access  Private/Admin
exports.updateKioskConfig = async (req, res) => {
    try {
        const { id } = req.params;
        const { config } = req.body;

        const kiosk = await Kiosk.findById(id);
        if (!kiosk) {
            return res.status(404).json({
                success: false,
                message: 'Kiosk not found'
            });
        }

        // Merge configuration
        kiosk.config = { ...kiosk.config, ...config };
        await kiosk.save();

        res.json({
            success: true,
            data: kiosk.config,
            message: 'Kiosk configuration updated'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// @desc    Get kiosk statistics
// @route   GET /api/kiosks/stats
// @access  Private
exports.getKioskStats = async (req, res) => {
    try {
        const total = await Kiosk.countDocuments();
        const online = await Kiosk.countDocuments({ status: 'online' });
        const offline = await Kiosk.countDocuments({ status: 'offline' });
        const maintenance = await Kiosk.countDocuments({ status: 'maintenance' });

        const recentHeartbeats = await Kiosk.find({ lastHeartbeat: { $gte: new Date(Date.now() - 300000) } })
            .select('name code lastHeartbeat');

        res.json({
            success: true,
            data: {
                total,
                online,
                offline,
                maintenance,
                recentHeartbeats: recentHeartbeats.length
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};